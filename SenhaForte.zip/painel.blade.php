<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link href="{{ asset('painel/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('painel/css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('painel/css/custom.css') }}" rel="stylesheet">

    <!-- Link Script Online Senha Forte-->   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/zxcvbn/4.2.0/zxcvbn.js"></script>
    
</head>
<body class="{{ (in_array(Request::route()->getName(), ['password.email', 'password.reset', 'login'])) ? 'body-bg-color' : 'sidebar-mini'}}">

    <div class="wrapper">
        @if (\Auth::check())
            @include('layouts.header')
            @include('layouts.aside')
        @endif

        @yield('content')

    </div>

    <!-- Scripts -->
    <script src="{{ asset('painel/js/jquery.min.js') }}"></script>
    <script src="{{ asset('painel/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('painel/js/script.js') }}"></script>
    <script src="{{ asset('painel/js/sweetalert.min.js') }}"></script>

    <script type="text/javascript">
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
    </script>
    <!--Script da Senha Forte-->
     <script>
        var strength = {
        0: "Muito ruim ☹",
        1: "Ruim ☹",
        2: "Fraca ☹",
        3: "Boa ☺",
        4: "Forte ☻"
        }

        var password = document.getElementById('password');
        var meter = document.getElementById('password-strength-meter');
        var text = document.getElementById('password-strength-text');

        password.addEventListener('input', function()
        {
        var val = password.value;
        var result = zxcvbn(val);

        // Update the password strength meter
        meter.value = result.score;

        // Update the text indicator
        if(val !== "") {
            text.innerHTML = "Força: " + "<strong>" + strength[result.score] + "</strong>" + "<span class='feedback'>" +  " " + "</span"; 
        }
        else {
            text.innerHTML = "";
        }
        });
    </script>
    

    @yield('script')
</body>
</html>
