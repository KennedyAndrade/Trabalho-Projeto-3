<?php

class homeController extends Controller
{
    private $user;
    
    public function __construct()
    {
        parent::__construct();
    }
    
    public function index()
    {
        $dado = array();
        $this->loadtemplate('home',$dados);
    }
}