<!DOCTYPE html>
<html>
<head>
    <!--Meta Tags-->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mind & Health - Saúde Física e Mental</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!--Bootstrap CSS-->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/normalize.css">
    

    <!--Bootstrap JS-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!--Favicon.ico Icone do Site-->
    <link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
    <link rel="manifest" href="favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

</head>
<body>
   <!-- Menu/Nav-bar-->
   <nav class="navbar navbar-expand-lg  navbar-secondary bg-secondary">
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <a class="navbar-brand" href="index.php">
                    <img src="img/logo.png" width="150" height="150" alt="">
                </a>
                 <ul class="navbar-nav ml-auto">
                      <!--<li class="nav-item">
                        <a class="nav-link text-white" href="#">Sobre</a>
                      </li>
                        -->
                            <li class="nav-item">
                                <a class="nav-link text-white font-weight-bold" href="#">E-books</a>
                              </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link text-white dropdown-toggle font-weight-bold" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Artigos</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                              <a class="dropdown-item disabled font-weight-bold" href="#">Nutrição</a>
                              <a class="dropdown-item text-success font-weight-bold" href="pag_1.html">Dicas Fit</a>
                              <a class="dropdown-item text-success font-weight-bold" href="#">Curiosidades Fit</a>
                            <div class="dropdown-divider"></div>
                              <a class="dropdown-item disabled font-weight-bold" href="#">Saúde Mental</a>
                              <div class="dropdown-divider"></div>
                              <a class="dropdown-item text-success font-weight-bold" href="#">Dicas Especializadas</a>
                            <div class="dropdown-divider"></div>
                             <a class="dropdown-item disabled font-weight-bold" href="#">Saúde Física</a>
                             <a class="dropdown-item text-success font-weight-bold" href="#">Esportes</a>
                            </div>
                          </li>
                            <li class="nav-item">
                                <a class="nav-link text-white font-weight-bold" href="#">Contato</a>
                            </li>
                           <li class="nav-item dropdown">
                            <a class="nav-link  text-white dropdown-toggle font-weight-bold" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Ver mais</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                              <a class="dropdown-item text-success font-weight-bold" href="#">Entrar</a>
                              <a class="dropdown-item text-success font-weight-bold" href="#">Cadastro</a>
                              <div class="dropdown-divider"></div>
                              <a class="dropdown-item text-success font-weight-bold" href="#">Ajuda</a>
                            </div>
                           </li>
                            
                  </ul>
                  <!-- <form class="form-inline my-2 my-lg-0">
                      <input class="form-control mr-sm-2" type="search" placeholder="Buscar..." aria-label="Search">
                      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pesquisar</button>
                  </form>-->
             </div>
    </nav>
      <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a class="text-success font-weight-bold font-weight-bold" href="index.php">Home / Página Inicial</a></li>
          </ol>
        </nav>
       

   <!--Banner/Carrousel-->
    <div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
    
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-2" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-2" data-slide-to="1"></li>
            <li data-target="#carousel-example-2" data-slide-to="2"></li>
        </ol>
        <!--Slides-->
        <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
            <div class="view">
                <img class="d-block w-100" src="img/slide.jpg" alt="First slide">
                <div class="mask rgba-black-light"></div>
            </div>
            <div class="carousel-caption">
                <h3 class="h3-responsive  font-weight-bold ">Saúde Física</h3>
                <p>Corpo e Mente Alinhados</p>
            </div>
            </div>
            <div class="carousel-item">
            <!--Mask color-->
            <div class="view">
                <img class="d-block w-100" src="img/slide9.jpg"  alt="Second slide">
                <div class="mask rgba-black-strong"></div>
            </div>
            <div class="carousel-caption">
                <h3 class="h3-responsive  font-weight-bold">Alimentação Saudável</h3>
                <p>Alimentação e Mente Alinhadas</p>
            </div>
            </div>
            <div class="carousel-item">
            <!--Mask color-->
            <div class="view">
                <img class="d-block w-100" src="img/slide7.jpg"  alt="Third slide">
                <div class="mask rgba-black-slight"></div>
            </div>
            <div class="carousel-caption">
                <h3 class="h3-responsive  font-weight-bold">Saúde Mental</h3>
                <p>Mente e Corpo Alinhados</p>
            </div>
            </div>
        </div>

        <!--Controls-->
        <a class="carousel-control-prev" href="#carousel-example-2" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel-example-2" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <br>
    
   <!-- Ebooks com Cards-->
   <div class="card-deck">
      <div class="card">
        <img class="card-img-top" src="img/card1.jpg" alt="Imagem de capa do card">
        <div class="card-body">
          <h5 class="card-title">Título do card</h5>
          <p class="card-text">Este é um card maior com suporte a texto embaixo, que funciona como uma introdução a um conteúdo adicional. Este conteúdo é um pouco maior, para demonstração.</p>
      </div>
      <div class="card-footer">
        <button type="button" class="btn btn-primary btn-lg">Ler mais</button>
      </div>
    </div>
  <div class="card">
    <img class="card-img-top" src="img/card2.jpg" alt="Imagem de capa do card">
    <div class="card-body">
      <h5 class="card-title">Título do card</h5>
      <p class="card-text">Este é um card com suporte a texto embaixo, que funciona como uma introdução a um conteúdo adicional.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Atualizados 3 minutos atrás</small>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="img/card3.jpg" alt="Imagem de capa do card">
    <div class="card-body">
      <h5 class="card-title">Título do card</h5>
      <p class="card-text">Este é um card maior com suporte a texto embaixo, que funciona como uma introdução a um conteúdo adicional. Este card tem o conteúdo ainda maior que o primeiro, para mostrar a altura igual, em ação.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Atualizados 3 minutos atrás</small>
    </div>
  </div>
</div>

<!-- Divisão Dos Cards-->
<br>
<div class="card-deck">
      <div class="card">
        <img class="card-img-top" src="img/card4.jpg" alt="Imagem de capa do card">
        <div class="card-body">
          <h5 class="card-title">Título do card</h5>
          <p class="card-text">Este é um card maior com suporte a texto embaixo, que funciona como uma introdução a um conteúdo adicional. Este conteúdo é um pouco maior, para demonstração.</p>
      </div>
      <div class="card-footer">
        <small class="text-muted">Atualizados 3 minutos atrás</small>
      </div>
    </div>
  <div class="card">
    <img class="card-img-top" src="img/card2.jpg" alt="Imagem de capa do card">
    <div class="card-body">
      <h5 class="card-title">Título do card</h5>
      <p class="card-text">Este é um card com suporte a texto embaixo, que funciona como uma introdução a um conteúdo adicional.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Atualizados 3 minutos atrás</small>
    </div>
  </div>
  <div class="card">
    <img class="card-img-top" src="img/card3.jpg" alt="Imagem de capa do card">
    <div class="card-body">
      <h5 class="card-title">Título do card</h5>
      <p class="card-text">Este é um card maior com suporte a texto embaixo, que funciona como uma introdução a um conteúdo adicional. Este card tem o conteúdo ainda maior que o primeiro, para mostrar a altura igual, em ação.</p>
    </div>
    <div class="card-footer">
      <small class="text-muted">Atualizados 3 minutos atrás</small>
    </div>
  </div>
</div>


    <!-- Artigos/Blog-->
    <h1>Ebooks</h1>

    <!--Botão Subir ao Topo-->
    <!-- Footer/Rodapé-->
 <!-- Footer -->
 <div class="p-3 mb-2 bg-secondary text-white" .bg-secondary>
<footer class="page-footer font-small stylish-color-dark pt-4">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-4 mx-auto">

          <!-- Content -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Mind & Health</h5>
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Informações</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Sobre</a>
            </li>
            <li>
              <a href="#!" class="text-white">Artigos</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ebooks</a>
            </li>
            <li>
              <a href="#!" class="text-white">Termos e condições de uso</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Atendimento</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Dúvidas</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ajuda</a>
            </li>
            <li>
              <a href="#!" class="text-white">mindhealth@hotmail.com</a>
            </li>
            <li>
              <a href="#!" class="text-white"></a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-3 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Newsletter</h5>
          <p>Assine nossa newsletter e receba dicas e novidades para uma vida mais saudável</p>
          
          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Link 1</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 2</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 3</a>
            </li>
            <li>
              <a href="#!" class="text-white">Link 4</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <hr>

    <!-- Call to action -->
    <ul class="list-unstyled list-inline text-center py-2">
      <li class="list-inline-item">
        <h5 class="mb-1">Cadastro Grátis</h5>
      </li>
      <li class="list-inline-item">
        <a href="#!" class="btn btn-danger btn-rounded bg-success">cadastrar!</a>
      </li>
    </ul>
    <!-- Call to action -->

    <hr>

    <!-- Social buttons -->
    <ul class="list-unstyled list-inline text-center">
      <li class="list-inline-item">
        <a class="btn-floating btn-fb mx-1">
          <i class="fab fa-facebook-f"> </i>
        </a>
      </li>
      <li class="list-inline-item">
        <a class="btn-floating btn-tw mx-1">
          <i class="fab fa-twitter"> </i>
        </a>
      </li>
      <li class="list-inline-item">
        <a class="btn-floating btn-gplus mx-1">
          <i class="fab fa-google-plus-g"> </i>
        </a>
      </li>
      <li class="list-inline-item">
        <a class="btn-floating btn-li mx-1">
          <i class="fab fa-linkedin-in"> </i>
        </a>
      </li>
      <li class="list-inline-item">
        <a class="btn-floating btn-dribbble mx-1">
          <i class="fab fa-dribbble"> </i>
        </a>
      </li>
    </ul>
    <!-- Social buttons -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2019 Copyright:
      <a href="https://github.com/KennedyAndrade/Trabalho-Projeto-3/" class="text-success"> Mind & Health</a>
    </div>
    <!-- Copyright -->
</footer>
</div>
<!-- Footer -->


</body>
<!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</html>