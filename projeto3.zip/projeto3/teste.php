<!DOCTYPE html>
<html>
<head>
    <!--Meta Tags-->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mind & Health - Saúde Física e Mental</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!--Bootstrap CSS e CSS-->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/normalize.css">
    <!-- Fonte Awesome icone email-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!--Bootstrap JS-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--Import Google Icon Font-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    
    <!--Favicon.ico Icone do Site-->
    <link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
    <link rel="manifest" href="favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

</head>
<body>
   <!-- Menu/Nav-bar-->
   <nav class="navbar navbar-expand-lg  navbar-secondary bg-dark">
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <a class="navbar-brand" href="teste.php">
                    <img src="img/logo.png" width="150" height="150" alt="">
                </a>
                 <ul class="navbar-nav ml-auto">
                 <li class="nav-item">
                           <a class="nav-link text-white font-weight-bold" href="teste.php">Home</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link text-white font-weight-bold" href="sobre.php">Sobre</a>
                        </li>
                            <li class="nav-item">
                                <a class="nav-link text-white font-weight-bold" href="#">E-books</a>
                              </li>
                            <li class="nav-item">
                                <a class="nav-link text-white font-weight-bold" href="#">Contato</a>
                            </li>
                            <li class="nav-item dropdown">
                            <a class="nav-link text-white dropdown-toggle font-weight-bold" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Artigos</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                              <a class="dropdown-item disabled font-weight-bold" href="#">Nutrição</a>
                              <a class="dropdown-item text-success font-weight-bold" href="pag_1.html">Dicas Fit</a>
                              <a class="dropdown-item text-success font-weight-bold" href="#">Curiosidades Fit</a>
                            <div class="dropdown-divider"></div>
                              <a class="dropdown-item disabled font-weight-bold" href="#">Saúde Mental</a>
                              <div class="dropdown-divider"></div>
                              <a class="dropdown-item text-success font-weight-bold" href="#">Dicas Especializadas</a>
                            <div class="dropdown-divider"></div>
                             <a class="dropdown-item disabled font-weight-bold" href="#">Saúde Física</a>
                             <a class="dropdown-item text-success font-weight-bold" href="#">Esportes</a>
                            </div>
                          </li>
                           <li class="nav-item dropdown">
                            <a class="nav-link  text-white dropdown-toggle font-weight-bold" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Ver mais</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                              <a class="dropdown-item text-success font-weight-bold" href="#">Entrar</a>
                              <a class="dropdown-item text-success font-weight-bold" href="#">Cadastro</a>
                              <div class="dropdown-divider"></div>
                              <a class="dropdown-item text-success font-weight-bold" href="#">Ajuda</a>
                            </div>
                           </li>
                            
                  </ul>
                  <!-- <form class="form-inline my-2 my-lg-0">
                      <input class="form-control mr-sm-2" type="search" placeholder="Buscar..." aria-label="Search">
                      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pesquisar</button>
                  </form>-->
             </div>
    </nav>
      <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a class="text-success font-weight-bold font-weight-bold" href="teste.php">Página Inicial</a></li>
          </ol>
        </nav>
       

   <!--Banner/Carrousel-->
    <div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
    
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-2" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-2" data-slide-to="1"></li>
            <li data-target="#carousel-example-2" data-slide-to="2"></li>
        </ol>
        <!--Slides-->
        <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
            <div class="view">
                <img class="d-block w-100" src="img/slide.jpg" alt="First slide">
                <div class="mask rgba-black-light"></div>
            </div>
            <div class="carousel-caption">
                <h3 class="h3-responsive  font-weight-bold ">Saúde Física</h3>
                <p>Corpo e Mente Alinhados</p>
            </div>
            </div>
            <div class="carousel-item">
            <!--Mask color-->
            <div class="view">
                <img class="d-block w-100" src="img/slide9.jpg"  alt="Second slide">
                <div class="mask rgba-black-strong"></div>
            </div>
            <div class="carousel-caption">
                <h3 class="h3-responsive  font-weight-bold">Alimentação Saudável</h3>
                <p>Alimentação e Mente Alinhadas</p>
            </div>
            </div>
            <div class="carousel-item">
            <!--Mask color-->
            <div class="view">
                <img class="d-block w-100" src="img/slide7.jpg"  alt="Third slide">
                <div class="mask rgba-black-slight"></div>
            </div>
            <div class="carousel-caption">
                <h3 class="h3-responsive  font-weight-bold">Saúde Mental</h3>
                <p>Mente e Corpo Alinhados</p>
            </div>
            </div>
        </div>

        <!--Controls-->
        <a class="carousel-control-prev" href="#carousel-example-2" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel-example-2" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <br>
   

  <!-- Ebook Download via Email-->
  <div class="jumbotron bg-success text-center" id="Team">
    <h1 class="text-white display-4">Ebook Gratuito - Esporte para seu dia a dia</h1>
    <div class="container">    
        <img class="border-right-0 rounded" src="img/ebook3.png" alt="Imagem de capa do card">
          <h4 class="text-white">Baixe Gratuitamente nosso ebook: <br>E aprenda como sua saúde física e mental mudam através da prática <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">de esportes</h4>
          <br>
          <br>
            <a href="#" class="btn btn-secondary btn-lg btn-block bg-primary border border-light">Baixar Ebook</a>
    </div>
  </div>
  <div class="jumbotron jumbotron-fluid bg-white">
      <div lass="container pt-5" id="Courses">
        <h1 class="display-4 text-center text-success">Ebooks</h1>
        <!-- Divisão para os ebooks-->
        <div class="row">
            <div class="col-sm-6">
              <div class="card ">
                <div class="card-body rounded-bottom border border-secondary text-center">
                  <h3 class="card-title">Titulo do Ebook</h3>
                  <img class="card-img-top" src="img/ebook.jpg" alt="Card image cap">
                  <p class="card-text lead">Descrição do Ebook.</p>
                  <a href="#" class="btn btn-primary bg-light text-dark border border-success">Comprar Ebook</a>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="card">
                <div class="card-body rounded-bottom border border-secondary text-center">
                  <h3 class="card-title">Titulo do Ebook</h3>
                  <img class="card-img-top" src="img/ebook.jpg" alt="Card image cap">
                  <p class="card-text lead">Descrição do Ebook.</p>
                  <a href="#" class="btn btn-primary bg-light text-success border border-success">Comprar Ebook</a>
                </div>
              </div>
            </div>
        </div>
        <br>
        <br>
        <!-- Divisão para os ebooks-->
        <div class="row">
            <div class="col-sm-6">
              <div class="card ">
                <div class="card-body rounded-bottom border border-secondary text-center">
                  <h3 class="card-title">Titulo do Ebook</h3>
                  <img class="card-img-top" src="img/ebook.jpg" alt="Card image cap">
                  <p class="card-text lead">Descrição do Ebook.</p>
                  <a href="#" class="btn btn-primary bg-light text-dark border border-success">Comprar Ebook</a>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="card">
                <div class="card-body rounded-bottom border border-secondary text-center">
                  <h3 class="card-title">Titulo do Ebook</h3>
                  <img class="card-img-top" src="img/ebook.jpg" alt="Card image cap">
                  <p class="card-text lead">Descrição do Ebook.</p>
                  <a href="#" class="btn btn-primary bg-light text-dark border border-success">Comprar Ebook</a>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  
  <!-- Artigos/Blog-->
  <!-- Artigos com Cards-->
  <div class="jumbotron jumbotron-fluid">
    <h1 class="display-4 text-center text-success">Artigos Destaques</h1>
   <div class="card-columns">
    <!-- Divisão dos Cards-->
    <div class="card text-center">
        <img class="card-img-top" src="img/card1.jpg" alt="Card image cap">
        <h5 class="card-title">Artigo 1</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <footer class="blockquote-footer text-right">
         
           Kennedy Andrade - <cite title="Source Title">Artigo 157</cite>
        
        </footer>
        <br>
        <a href="#" class="btn btn-primary bg-success border border-success">Ler Artigo</a>
        <br>
        <br>
    </div>
    <!-- Divisão dos Cards-->
    <div class="card p-3 text-center">
        <img class="card-img-top" src="img/card1.jpg" alt="Card image cap">
        <h5 class="card-title">Artigo 1</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <footer class="blockquote-footer text-right">
         
           Kennedy Andrade - <cite title="Source Title">Artigo 157</cite>
        
        </footer>
        <br>
        <a href="#" class="btn btn-primary bg-success border border-success">Ler Artigo</a>
        <br>
        <br>
        
    </div>
  <div class="card text-center">
    <img class="card-img-top" src="img/card2.jpg" alt="Card image cap">
    <h5 class="card-title">Artigo 1</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <footer class="blockquote-footer text-right">
         
           Kennedy Andrade - <cite title="Source Title">Artigo 157</cite>
        
        </footer>
        <br>
        <a href="#" class="btn btn-primary bg-success border border-success">Ler Artigo</a>
        <br>
        <br>
  </div>
  <div class="card  text-center">
      <img class="card-img" src="img/card4.jpg" alt="Card image">
      <h5 class="card-title">Artigo 1</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <footer class="blockquote-footer text-right">
         
           Kennedy Andrade - <cite title="Source Title">Artigo 157</cite>
        
        </footer>
        <br>
        <a href="#" class="btn btn-primary bg-success border border-success">Ler Artigo</a>
        <br>
        <br>
  </div>
  <div class="card text-center">
    <img class="card-img" src="img/card4.jpg" alt="Card image">
    <h5 class="card-title">Artigo 1</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        <footer class="blockquote-footer text-right">
         
           Kennedy Andrade - <cite title="Source Title">Artigo 157</cite>
        
        </footer>
        <br>
        <a href="#" class="btn btn-primary bg-success border border-success">Ler Artigo</a>
        <br>
        <br>
  </div>
  <div class="card text-center">
    <img class="card-img" src="img/card4.jpg" alt="Card image">
    <h5 class="card-title">Artigo 1</h5>
        <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        <footer class="blockquote-footer text-right">
         
           Kennedy Andrade - <cite title="Source Title">Artigo 157</cite>
        
        </footer>
        <br>
        <a href="#" class="btn btn-primary bg-success border border-success">Ler Artigo</a>
        <br>
        <br>
  </div>
 </div>


 
  <!--Botão Mais Artigos-->
  <div class="text-center">
        <input type="submit" value="+ Mais artigos" class="btn btn-large btn-primary btn-lg bg-success border border-light"/>
    </div>
</div>

<!--Formulário para Contato-->
<h1 class="display-4 text-center text-success">Contato</h1>
<form>
  <div class="form-group text-center">
    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Nome">
  </div>
  <div class="form-group">
    <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="E-mail">
  </div>
  <div class="form-group">
    <textarea class="form-control" rows="5" id="mensagem" placeholder="Mensagem"></textarea>
</div>
<div class="text-center">
  <input class="btn btn-primary btn-lg text-center bg-success border border-success" type="submit" value="Enviar">
</div>
<br>
<br>
</form>

    <!--Botão Subir ao Topo-->
 <!-- Footer/Rodapé-->
 <!-- Footer -->
 <div class="p-3 mb-2 bg-dark text-white" .bg-secondary>
<footer class="page-footer font-small stylish-color-dark pt-4">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-4 mx-auto">

          <!-- Content -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Mind & Health</h5>
          <p>Nossa missão é cuidar de você e de sua saúde. De uma forma, que só a M & H (Mind & Health) sabe.</p>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Informações</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Sobre</a>
            </li>
            <li>
              <a href="#!" class="text-white">Artigos</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ebooks</a>
            </li>
            <li>
              <a href="#!" class="text-white">Termos e condições de uso</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Atendimento</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Dúvidas</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ajuda</a>
            </li>
            <li>
              <a href="#!" class="text-white">mindhealth@hotmail.com</a>
            </li>
            <li>
              <a href="#!" class="text-white"></a>
            </li>
          </ul>

        </div>
        
        

    </div>
    <hr>
    <!-- Grid column -->
        
    <div class="container">
          <div class="row">
            <div class="col-md-8 mx-auto">

              <!-- Links -->
              <h3 class="font-weight-bold text-uppercase mt-3 mb-4 text-success text-center">Newsletter</h3>
              <h6 class="font-weight-bold  mt-3 mb-4  text-center">Assine nossa newsletter e receba dicas e novidades para uma vida mais saudável</h6>
              <!-- Icone Newsletter-->     
      
               <div class="thumbnail center well well-sm text-center">
                    <form action="" method="post" role="form">
                          <div class="input-group">
                              <span class="input-group-addon">
                              <!--Aqui deverar ir um icone ou alguma estilização para o newsletter :) -->
                              </span>
                              <input class="form-control text-center" type="text" id="" name="" placeholder=">> SEU MELHOR E-MAIL AQUI! <<">
                          </div>
                          <input type="submit" value="Cadastrar" class="btn btn-large btn-primary btn-lg bg-success border border-light"/>
                    </form>
               </div>    
           </div>
        </div>
    </div>
        <!-- Grid column -->

    <!-- Social media Links/Links para rede social -->
    <hr>
        <div class="text-center py-3 ">
            <h3 class="font-weight-bold white-text  text-success text-center">Redes Sociais</h3>
                <ul class="list-inline redes text-center">
                    <a href="https://www.facebook.com/Mind-Health-1017661845098135/?modal=admin_todo_tour" target="_blank"><i class="fab fa-facebook fa-2x"></i></a>
                    <a href="https://www.instagram.com/mind_healthms/?hl=pt-b" target="_blank"><i class="fab fa-instagram fa-2x"></i></a>
                    <a href="" target="_blank"><i class="fab fa-youtube fa-2x"></i></a>
                    <a href="" target="_blank"><i class="fab fa-twitter fa-2x"></i></a>
                </ul>
        </div>
    <hr>

    <!-- Parte de formulário de cadastro grátis
    <hr>

    <ul class="list-unstyled list-inline text-center py-2">
      <li class="list-inline-item">
        <h5 class="mb-1">Cadastro Grátis</h5>
      </li>
      <li class="list-inline-item">
        <a href="#!" class="btn btn-danger btn-rounded bg-success">cadastrar!</a>
      </li>
    </ul>
    

    <hr>
    -->


    <!-- Copyright -->
    <div class="footer-copyright text-center py-3 font-weight-bold">© 2019 Copyright:
      <a href="https://github.com/KennedyAndrade/Trabalho-Projeto-3/" class="text-success font-weight-bold"> Mind & Health</a>
    </div>
    <!-- Copyright -->
</footer>
</div>
<!-- Footer -->


</body>
<!-- Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</html>