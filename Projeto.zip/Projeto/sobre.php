<!doctype html>
<html lang="pt-br">
  <head>
     <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
       <!--Import Google Icon Font-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <title>Sobre</title>
  </head>
  <body>
      <?php include_once __DIR__ .'/includes/navbar.php' ?>
      <img src="img/empresa.png" class="img-fluid" width="1350" height="800">
	<div class="C1">
		<div class="C2">
			<h1 class="C3 text-success">O que nós fazemos</h1>
			<p>A ... um dos maiores sites brasileiros de saúde educacional e de serviço gratuito, Também fazem parte desse segmento educacional os sites Saúde. Como auxílio para pessoas querem melhorar sua saúde física e mental.</p>
		</div>

		<div class="C2">
			<h1 class="C3 text-success">Quem nós somos</h1>
			<p>A Rede .... é uma empresa do litoral que administra websites, que são, em sua grande maioria, sites de educação. Instituída em 2019, conta com uma jovem equipe de profissionais que investe em transmissão de conhecimento através de novas tecnologias e busca melhorias para sempre atender às necessidades do seu público, prezando pela excelência do trabalho oferecido e pela satisfação dos clientes.</p>
		</div>

		<div class="C2">
			<h1 class="C3 text-success">Quem nós servimos</h1>
			<p>Nosso público é qualquer pessoa, em qualquer lugar, que acredite que a saúde física e mental pode resolver todos os problemas, aumentar a prosperidade e expandir o tempo de vida. É uma comunidade pequena de amigos empresariais e inovadores, inovadores e pioneiros, empresários e investidores.</p>
		</div>

		<div class="C2">
			<p class="S1 text-success">Coma Coisas Saúdavel Para Ter uma Saúde Impecável</p>
		</div>
	</div>
      
      <div class="p-3 mb-2 bg-secondary text-white" id="page-footer">
<footer class="page-footer font-small stylish-color-dark pt-4">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-4 mx-auto">

          <!-- Content -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Mind & Health</h5>
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Informações</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Sobre</a>
            </li>
            <li>
              <a href="#!" class="text-white">Artigos</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ebooks</a>
            </li>
            <li>
              <a href="#!" class="text-white">Termos e condições de uso</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Atendimento</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Dúvidas</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ajuda</a>
            </li>
            <li>
              <a href="#!" class="text-white">mindhealth@hotmail.com</a>
            </li>
            <li>
              <a href="#!" class="text-white"></a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-3 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Newsletter</h5>
          <p>Assine nossa newsletter e receba dicas e novidades para uma vida mais saudável</p>
     <!-- Icone Newsletter-->     
    <div class="container">
      <div class="row">
            <div class="thumbnail center well well-sm text-center">
                    <form action="" method="post" role="form">
                        <div class="input-group">
                          <span class="input-group-addon">
                           <!--Aqui deverar ir um icone ou alguma estilização para o newsletter :) -->
                          </span>
                          <input class="form-control" type="text" id="" name="" placeholder="Seu melhor e-mail">
                        </div>
                        <input type="submit" value="Cadastrar" class="btn btn-large btn-primary bg-success"/>
                  </form>
                </div>    
            </div>
  </div>

        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
    <!-- Footer Links -->

    <hr>
            <div class="col-lg-6 col-md-12">
                    <h5 class="white-text text-success">Redes Sociais</h5>
                    <ul class="list-inline redes text-right">
                    <a href="https://www.facebook.com/Mind-Health-1017661845098135/?modal=admin_todo_tour" rel="stylesheet"><i class="fab fa-facebook fa-2x"></i></a>
                    <a href="htthttps://www.instagram.com/mind_healthms/?hl=pt-b" rel="stylesheet"><i class="fab fa-instagram fa-2x"></i></a>
                    <a href=""><i class="fab fa-youtube fa-2x"></i></a>
                    <a href="" rel="stylesheet"><i class="fab fa-twitter fa-2x"></i></a>
                </ul>
        </div>
    <hr>


    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2019 Copyright:
      <a href="https://github.com/KennedyAndrade/Trabalho-Projeto-3/" class="text-success"> Mind & Health</a>
    </div>
    <!-- Copyright -->
</footer>
</div>
<!-- Footer -->
      
      
      
      
      
      <!-- Bootstrap JS -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript">
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            $(".navbar").removeClass("bigMenu");
        }else{
            $(".navbar").addClass("bigMenu");
        }
    });
</script>
  </body>
</html>