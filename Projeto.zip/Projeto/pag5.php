<!doctype html>
<html lang="pt-br">
  <head>
    <!--Meta Tags-->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mind & Health - Saúde Física e Mental</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <!--Import Google Icon Font-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
      <!--Favicon.ico Icone do Site-->
    <link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
    <link rel="manifest" href="favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
  </head>
  <body>
       <?php include_once __DIR__ .'/includes/navbar.php' ?>
    <div class="container pt-5 " id="Courses"> 
      <h2 class="text-center text-success">Saúde Fisica</h2>
        <div class="text-center">            
          <img src="img/paz.jpg" class="img-fluid">
        </div>
      <div class="row mt-4">
        <div class="text-center h5">        
        <p class="card-text">
         <h4 class="font-weight-bold">A importância da atividade para a saúde física e mental</h4>
             <p class="font-weight-normal">Praticar atividade física regular é muito importante em qualquer idade. Não é à toa que é algo que todos os profissionais da área da saúde recomendam.<br>O aumento da aptidão física pode prevenir doenças, como problemas cardíacos, obesidade, diabetes e câncer, além de melhorar o humor e a autoestima e diminuir a chance de desenvolver transtornos psiquiátricos, como depressão e ansiedade.<br>Dessa forma, a necessidade de modificar o estilo de vida sedentário é cada vez mais vital.<br>A seguir, mostramos a importância da prática de atividade física regular e como ela está relacionada à melhora da saúde física e mental.</p>
             
         <h4 class="font-weight-bold">Como manter sua saúde mental em dia</h4>
             <p class="font-weight-normal">Para manter uma boa saúde mental, é preciso cuidar bem do seu corpo, isto é, dormir bem, alimentar-se de forma adequada e praticar exercício físico regularmente.<br>Atividade física: uma grande aliada da saúde mental<br>A prática de atividade física, por exemplo, proporciona uma sensação de bem-estar e relaxamento.<br>Quando nos exercitamos, o nosso corpo libera endorfina, substância natural produzida pelo cérebro durante e após a realização de uma atividade física. A liberação de endorfina – também conhecida como hormônio da alegria – ajuda a relaxar, reduz o estresse e a ansiedade e melhora o humor.</p>
             
         <h4 class="font-weight-bold">Outros cuidados</h4>
             <p class="font-weight-normal">Mantenha-se em contato com a natureza.<br>
             Fique longe do seu celular;<br>
             Além dos cuidados com o corpo, veja algumas dicas para manter uma boa saúde mental:<br>
             Reserve um tempo para momentos de lazer e convivência com amigos e familiares;<br>
             Dedique tempo às pessoas que são essenciais para você.<br>
             Tudo isso ajuda a ampliar a nossa visão de mundo, ter maior firmeza diante dos desafios da vida, além de contribui para a manutenção de um bom estado de saúde mental.</p><br>
             
             <div class="text-center">     
                <img src="img/medi.jpg"class="img-fluid ">
            </div>
            
         <h4 class="font-weight-bold">Saúde física</h4>
             <p class="font-weight-normal">A saúde física, por sua vez, envolve a condição geral do corpo no que se refere a doenças e ao vigor físico.<br>Assim, uma pessoa fisicamente saudável possui um bom funcionamento do organismo e de suas funções vitais.<br>Para promover a saúde física, é preciso atingir e permanecer com um peso apropriado, reduzir o consumo de álcool, parar de fumar e, claro, praticar algum tipo de atividade física.</p>
             
            
        <h4 class="font-weight-bold">Consequências do sedentarismo</h4>
            <p class="font-weight-normal">O sedentarismo nada mais é do que a ausência de atividade física suficiente para manter a saúde. Adotar um estilo de vida sedentário traz muitos malefícios para a saúde física e mental.Estima-se que cerca de 5,3 milhões de mortes são causadas pela inatividade física por ano no mundo, segundo diagnóstico publicado na revista médica Lancet.<br>No Brasil, de acordo com uma pesquisa realizada pelo Ministério do Esporte, o sedentarismo atingiu 45,9% dos brasileiros em 2013.<br>Intitulado de Diagnóstico Nacional do Esporte, a pesquisa alegou que o problema é mais comum entre as mulheres: 50,4% são sedentárias.<br>O estudo mostrou também o percentual de sedentários em outros países do mundo.<br>A Argentina apresentou a maior taxa: 68,3% da população não pratica atividades físicas. Em Portugal, a taxa chega a 53%; nos Estados Unidos, 40,5%; e na China, 31%.<br>Os países que apresentaram menor percentual de pessoas sedentárias foram índia, Inglaterra e França com 16%, 17% e 22%, respectivamente.</p>

       <h4 class="font-weight-bold">Saia do sedentarismo: faça 150 minutos de atividade física por semana</h4>
            <p class="font-weight-normal">Para combater o sedentarismo, de acordo com a OMS, Organização Mundial da Saúde, é recomendado que seja feito 150 minutos de atividade de intensidade moderada por semana. Logo, podem ser feitos 30 minutos de atividade física em cinco ou mais dias por semana.<br>Mas, atenção: pessoas sedentárias devem começar lentamente, aumentando pouco a pouco a intensidade e duração dos exercícios.</p>
          </p>
             <div class="card font-weight-bold">
              <div class="card-header">
               Fonte consultada:
              </div>
              <div class="card-body">
                <blockquote class="blockquote mb-0">
                  <footer class="blockquote-footer"> Postado por Gympass | Bem-estar, Lifestyle, Saúde
                     <a href="https://news.gympass.com/atividade-fisica-para-saude-fisica-e-mental/" class="stretched-link">https://news.gympass.com/atividade-fisica-para-saude-fisica-e-mental/</a></footer>
                </blockquote>
              </div>
            </div>
          </div>
      </div>
  </div>
       <div class="p-3 mb-2 bg-dark text-white" id="page-footer">
           <footer class="page-footer font-small stylish-color-dark pt-4">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-4 mx-auto">

          <!-- Content -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Mind & Health</h5>
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Informações</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Sobre</a>
            </li>
            <li>
              <a href="#!" class="text-white">Artigos</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ebooks</a>
            </li>
            <li>
              <a href="#!" class="text-white">Termos e condições de uso</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Atendimento</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Dúvidas</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ajuda</a>
            </li>
            <li>
              <a href="#!" class="text-white">mindhealth@hotmail.com</a>
            </li>
            <li>
              <a href="#!" class="text-white"></a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-3 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Newsletter</h5>
          <p>Assine nossa newsletter e receba dicas e novidades para uma vida mais saudável</p>
     <!-- Icone Newsletter-->     
    <div class="container">
      <div class="row">
            <div class="thumbnail center well well-sm text-center">
                    <form action="" method="post" role="form">
                        <div class="input-group">
                          <span class="input-group-addon">
                           <!--Aqui deverar ir um icone ou alguma estilização para o newsletter :) -->
                          </span>
                          <input class="form-control" type="text" id="" name="" placeholder="Seu melhor e-mail">
                        </div>
                        <input type="submit" value="Cadastrar" class="btn btn-large btn-primary bg-success"/>
                  </form>
                </div>    
            </div>
  </div>

        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
    <!-- Footer Links -->

    <hr>
            <div class="col-lg-6 col-md-12">
                    <h5 class="white-text text-success">Redes Sociais</h5>
                    <ul class="list-inline redes text-right">
                    <a href="https://www.facebook.com/Mind-Health-1017661845098135/?modal=admin_todo_tour" rel="stylesheet"><i class="fab fa-facebook fa-2x"></i></a>
                    <a href="htthttps://www.instagram.com/mind_healthms/?hl=pt-b" rel="stylesheet"><i class="fab fa-instagram fa-2x"></i></a>
                    <a href=""><i class="fab fa-youtube fa-2x"></i></a>
                    <a href="" rel="stylesheet"><i class="fab fa-twitter fa-2x"></i></a>
                </ul>
        </div>
    <hr>


    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2019 Copyright:
      <a href="https://github.com/KennedyAndrade/Trabalho-Projeto-3/" class="text-success"> Mind & Health</a>
    </div>
    <!-- Copyright -->
</footer>
</div>
<!-- Footer -->
      
      
      <!-- Bootstrap JS -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>