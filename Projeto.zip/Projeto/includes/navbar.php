<nav class="navbar navbar-expand-lg bigMenu  navbar-secondary fixed-top">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <a class="navbar-brand" href="index.php">
            <img src="img/logo.png" class="img-fluid" alt="logo">
        </a>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link text-white" href="sobre.php">Sobre</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#">E-books</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#">Contato</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link text-white dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Artigos
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item disabled" href="index.php">Nutrição</a>
                    <a class="dropdown-item text-success" href="pag2.php">Dicas Fit</a>
                    <a class="dropdown-item text-success" href="pag1.php">Curiosidades Fit</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item disabled" href="index.php">Saúde Mental</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-success" href="pag3.php">Dicas Especializadas</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item disabled" href="index.php">Saúde Física</a>
                    <a class="dropdown-item text-success" href="#">Esportes</a>
                    <a class="dropdown-item text-success" href="#">Esportes</a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link  text-white dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Ver mais
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item text-success" href="#">Entrar</a>
                    <a class="dropdown-item text-success" href="#">Cadastro</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item text-success" href="#">Ajuda</a>
                </div>
            </li>
        </ul>
    </div>
</nav>
