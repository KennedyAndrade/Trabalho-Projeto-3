<!doctype html>
<html lang="pt-br">
  <head>
       <!--Meta Tags-->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mind & Health - Saúde Física e Mental</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
       <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/style.css"> 
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Fonte Awesome icone email-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <!--Import Google Icon Font-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
      
    <script src="js/jquery.js"></script>
		<script src="js/scripts.js"></script>


      <!--Favicon.ico Icone do Site-->
    <link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
    <link rel="manifest" href="favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
  </head>
  <body>
      <?php include_once __DIR__ .'/includes/navbar.php' ?>
       <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
              <div class="carousel-caption">
                <h3 class="h3-responsive  font-weight-bold ">Saúde</h3>
                <p>Corpo e Mente Alinhados</p>
            </div>
            <div class="carousel-item active">
              <img src="img/slide.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img src="img/slide9.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img src="img/slide7.jpg" class="d-block w-100" alt="...">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
       </div>
<!-- nutricao-->
      <!--https://www.minhavida.com.br/alimentacao/tudo-sobre/20643-alimentacao-saudavel-->
<div class="container pt-5" id="card-link1"> 
    <h2 class="text-center text-success font-weight-bold font-weight-bold">NUTRIÇÃO</h2>  
    <div class="row mt-4">        
      <div class="col-lg-6 mb-4">     
        <img src="img/curiosidade.jpg" alt="" class="img-fluid">
      </div>  
      <div class="col-lg-6">    
         <a href="pag1.php" class="card-link">Dicas fitness fáceis para incorporar no dia a dia</a><br>
          <p>Ter uma alimentação saudável proporciona uma série de benefícios para as pessoas. Ela contribui para a melhora no sistema imunológico, na qualidade de sono, no trânsito intestinal, no humor, na capacidade de concentração e pode contribuir até mesmo para a perda de peso. Em gestantes, ela é essencial para o bom desenvolvimento do feto e em mulheres que amamentam irá contribuir para o desenvolvimento saudável do bebê. Entre outros inúmeros benefícios.</p>
        <p class="card-text"><small class="text-muted">Última atualização 3 minutos atrás</small></p>
      </div>  
    </div>  

    <div class="row mt-4">   
      <div class="col-lg-6"> 
         <a href="pag2.php" class="card-link">5 Receitas fitness Detox fáceis para o dia-a-dia</a> <br>
          <p>Muito consumido por quem busca emagrecer, os sucos detox são grandes aliados da Dieta Detox, que tem como maior objetivo eliminar substâncias prejudiciais ao organismo. Essas substâncias podem vir de agrotóxicos, conservantes, gorduras saturadas, açúcares e sal em excesso e gordura trans.<br> Além disso, estes sucos têm ação antioxidante, ajudando a fortalecer o sistema imunológico e são ricos em fibras, que melhoram o trânsito intestinal. Além de auxiliar na perda de peso, os ingredientes que compõem os sucos são benéficos para a saúde, já que coopera com a limpeza do nosso organismo.</p>
           <p class="card-text"><small class="text-muted">Última atualização 3 minutos atrás</small></p> 
      </div>  
      <div class="col-lg-6 mb-4">   
        <img src="img/detoxVerde.jpg" alt="" class="img-fluid">
      </div>    
    </div> 
  </div>
       <!-- Final nutricao-->

        <!-- PARALLAX1-->
    <div class="parallax div1" data-divisor="2">
			<div class="text text-center">“A comida saudável  para o corpo.”</div>
    </div>

       <!-- comeco de saude mental-->
      <div class="container pt-5" id="card-link2"> 
    <h2 class="text-center text-success font-weight-bold font-weight-bold">SAÚDE MENTAL</h2>  
    <div class="row mt-4">        
      <div class="col-lg-6 mb-4">     
        <img src="img/amizade.jpg" alt="" class="img-fluid">   
      </div>  
      <div class="col-lg-6">    
         <a href="pag3.php" class="card-link">Dicas de saúde mental para melhorar seu dia</a><br>
          <p>Todo modelo de atenção em saúde mental estabelece intermediações entre o aspecto técnico e o político e nele devem estar presentes os interesses e as necessidades da sociedade, o saber técnico, as diretrizes políticas e os modos de gestão dos sistemas públicos. Isso implica um processo de contínua criatividade voltado para as necessidades mutáveis dos usuários, para as características sociorregionais e para o oferecimento dos serviços. </p>
        <p class="card-text"><small class="text-muted">Última atualização 3 minutos atrás</small></p>
      </div>  
    </div>  
  </div> 
        <!-- Final saude mental
      -->

           <!-- PARALLAX2  https://www.pensador.com/bemestar/-->
        <div class="parallax div2 text-center" data-divisor="4">
			    <div class="text">"Corpo, Mente e Espírito estão interligados"</div>
		   </div>
        <!-- comeco saude fisica-->
      <div class="container pt-5" id="card-link3"> 
    <h2 class="text-center text-success font-weight-bold font-weight-bold">SAÚDE FÍSICA</h2>  
    <div class="row mt-4">        
      <div class="col-lg-6">    
         <a href="pag4.php" class="card-link">Dicas de exercicios para incorporar seu cotidiano</a><br>
          <p>Ter uma alimentação saudável proporciona uma série de benefícios para as pessoas. Ela contribui para a melhora no sistema imunológico, na qualidade de sono, no trânsito intestinal, no humor, na capacidade de concentração e pode contribuir até mesmo para a perda de peso. Em gestantes, ela é essencial para o bom desenvolvimento do feto e em mulheres que amamentam irá contribuir para o desenvolvimento saudável do bebê. Entre outros inúmeros benefícios.</p>
        <p class="card-text"><small class="text-muted">Última atualização 3 minutos atrás</small></p>
      </div>  
       <div class="col-lg-6 mb-4">     
        <img src="img/exercicio.jpg" alt="" class="img-fluid">
      </div>  
    </div>  

    <div class="row mt-4">
     <div class="col-lg-6 mb-4">   
        <img src="img/paz.jpg" alt="" class="img-fluid">
      </div>    
      <div class="col-lg-6"> 
         <a href="pag5.php" class="card-link">Dicas para sua cabeça, corpo e coração</a><br>
          <p>A saúde física engloba a condição geral do corpo em relação a doenças e ao vigor físico. Para uma pessoa ser considerada saudável, ela não deve ter doenças e possuir um metabolismo que apresente um bom funcionamento. Uma infância saudável, genética e condições de trabalho, são algumas das coisas que influenciam na saúde física.<br>As necessidades mais importantes do corpo são: sol, água, alimentos, exercícios, repouso e higiene. A saúde física enfraquece quando algumas dessas necessidades não são atendidas. </p>
           <p class="card-text"><small class="text-muted">Última atualização 3 minutos atrás</small></p> 
      </div>     
    </div> 
  </div>
       <!-- Final saude fisica-->
  </section>
      <div class="p-3 mb-2 bg-dark  text-white" .bg-secondary>
       <footer class="page-footer font-small stylish-color-dark pt-4" id="page-footer">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-4 mx-auto">

          <!-- Content -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Mind & Health</h5>
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Informações</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Sobre</a>
            </li>
            <li>
              <a href="#!" class="text-white">Artigos</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ebooks</a>
            </li>
            <li>
              <a href="#!" class="text-white">Termos e condições de uso</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Atendimento</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Dúvidas</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ajuda</a>
            </li>
            <li>
              <a href="#!" class="text-white">mindhealth@hotmail.com</a>
            </li>
            <li>
              <a href="#!" class="text-white"></a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-3 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Newsletter</h5>
          <p>Assine nossa newsletter e receba dicas e novidades para uma vida mais saudável</p>
     <!-- Icone Newsletter-->     
    <div class="container">
      <div class="row">
            <div class="thumbnail center well well-sm text-center">
                    <form action="" method="post" role="form">
                        <div class="input-group">
                          <span class="input-group-addon">
                           <!--Aqui deverar ir um icone ou alguma estilização para o newsletter :) -->
                          </span>
                          <input class="form-control" type="text" id="" name="" placeholder="Seu melhor e-mail">
                        </div>
                        <input type="submit" value="Cadastrar" class="btn btn-large btn-primary bg-success"/>
                  </form>
                </div>    
            </div>
  </div>

        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
    <!-- Footer Links -->

    <hr>
            <div class="col-lg-6 col-md-12">
                    <h5 class="white-text text-success">Redes Sociais</h5>
                    <ul class="list-inline redes text-right">
                    <a href="https://www.facebook.com/Mind-Health-1017661845098135/?modal=admin_todo_tour" rel="stylesheet"><i class="fab fa-facebook fa-2x"></i></a>
                    <a href="htthttps://www.instagram.com/mind_healthms/?hl=pt-b" rel="stylesheet"><i class="fab fa-instagram fa-2x"></i></a>
                    <a href=""><i class="fab fa-youtube fa-2x"></i></a>
                    <a href="" rel="stylesheet"><i class="fab fa-twitter fa-2x"></i></a>
                </ul>
        </div>
    <hr>


    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2019 Copyright:
      <a href="https://github.com/KennedyAndrade/Trabalho-Projeto-3/" class="text-success"> Mind & Health</a>
    </div>
    <!-- Copyright -->
</footer>
</div>
<!-- Footer -->

    <!-- Bootstrap JS -->
      
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>
</html>
