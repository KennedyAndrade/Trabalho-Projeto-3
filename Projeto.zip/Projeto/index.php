<!doctype html>
<html lang="pt-br">
  <head>
       <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/style.css"> 
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Fonte Awesome icone email-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <!--Import Google Icon Font-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  </head>
  <body>
      <?php include_once __DIR__ .'/includes/navbar.php' ?>

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
             <div class="carousel-caption">
                <h3 class="h3-responsive  font-weight-bold ">Saúde</h3>
                <p>Corpo e Mente Alinhados</p>
            </div>
            <div class="carousel-item active">
                <div class="d-flex align-items-center justify-content-center min-vh-100">
                    <img src="img/esteira.jpg" class="d-block w-100 img-fluid" alt="...">
                </div>
            </div>
            <div class="carousel-item">
                <div class="d-flex align-items-center justify-content-center min-vh-100">
                    <img src="img/leegumes.jpeg" class="d-block w-100 img-fluid" alt="...">
                </div>
            </div>
            <div class="carousel-item">
                <div class="d-flex align-items-center justify-content-center min-vh-100">
                    <img src="img/felicidade.jpeg" class="d-block img-fluid w-100" alt="...">
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
<!-- nutricao-->
      <!--https://www.minhavida.com.br/alimentacao/tudo-sobre/20643-alimentacao-saudavel-->
<div class="container pt-5" id="card-link1"> 
    <h2 class="text-center text-success font-weight-bold font-weight-bold">NUTRIÇÃO</h2>  
    <div class="row mt-4">        
      <div class="col-lg-6 mb-4">     
        <img src="img/cafe.jpeg" alt="" class="img-fluid">
      </div>  

      <div class="col-lg-6">    
         <a href="pag1.php" class="card-link">Dicas fitness fáceis para incorporar no dia a dia</a><br>
          <p>Ter uma alimentação saudável proporciona uma série de benefícios para as pessoas. Ela contribui para a melhora no sistema imunológico, na qualidade de sono, no trânsito intestinal, no humor, na capacidade de concentração e pode contribuir até mesmo para a perda de peso. Em gestantes, ela é essencial para o bom desenvolvimento do feto e em mulheres que amamentam irá contribuir para o desenvolvimento saudável do bebê. Entre outros inúmeros benefícios.</p>
        <p class="card-text"><small class="text-muted">Última atualização 3 minutos atrás</small></p>
      </div>  
    </div>  

    <div class="row mt-4">   
      <div class="col-lg-6"> 
         <a href="pag2.php" class="card-link">5 Receitas fitness Detox fáceis para o dia-a-dia</a> <br>
          <p>Muito consumido por quem busca emagrecer, os sucos detox são grandes aliados da Dieta Detox, que tem como maior objetivo eliminar substâncias prejudiciais ao organismo. Essas substâncias podem vir de agrotóxicos, conservantes, gorduras saturadas, açúcares e sal em excesso e gordura trans.<br> Além disso, estes sucos têm ação antioxidante, ajudando a fortalecer o sistema imunológico e são ricos em fibras, que melhoram o trânsito intestinal. Além de auxiliar na perda de peso, os ingredientes que compõem os sucos são benéficos para a saúde, já que coopera com a limpeza do nosso organismo.</p>
           <p class="card-text"><small class="text-muted">Última atualização 3 minutos atrás</small></p> 
      </div>  
      <div class="col-lg-6 mb-4">   
        <img src="img/detox.jpeg" alt="" class="img-fluid">
      </div>    
    </div> 
  </div>
      <!-- Final nutricao-->
      <div class="container pt-5" id="card-link2"> 
    <h2 class="text-center text-success font-weight-bold font-weight-bold">SAÚDE MENTAL</h2>  
    <div class="row mt-4">        
      <div class="col-lg-6 mb-4">     
        <img src="img/amizade.jpeg" alt="" class="img-fluid">
         
      </div>  

      <div class="col-lg-6">    
         <a href="" class="card-link">Dicas de saúde mental para melhorar seu dia</a><br>
          <p>Ter uma alimentação saudável proporciona uma série de benefícios para as pessoas. Ela contribui para a melhora no sistema imunológico, na qualidade de sono, no trânsito intestinal, no humor, na capacidade de concentração e pode contribuir até mesmo para a perda de peso. Em gestantes, ela é essencial para o bom desenvolvimento do feto e em mulheres que amamentam irá contribuir para o desenvolvimento saudável do bebê. Entre outros inúmeros benefícios.</p>
        <p class="card-text"><small class="text-muted">Última atualização 3 minutos atrás</small></p>
      </div>  
    </div>  
  </div> 
        <!-- Final saude mental-->
      <div class="container pt-5" id="card-link3"> 
    <h2 class="text-center text-success font-weight-bold font-weight-bold">SAÚDE FÍSICA</h2>  
    <div class="row mt-4">        
      <div class="col-lg-6 mb-4">     
        <img src="img/caminhada.jpeg" alt="" class="img-fluid">
      </div>  

      <div class="col-lg-6">    
         <a href="pag1.php" class="card-link">Dicas de exercicios fáceis para incorporar no dia a dia</a><br>
          <p>Ter uma alimentação saudável proporciona uma série de benefícios para as pessoas. Ela contribui para a melhora no sistema imunológico, na qualidade de sono, no trânsito intestinal, no humor, na capacidade de concentração e pode contribuir até mesmo para a perda de peso. Em gestantes, ela é essencial para o bom desenvolvimento do feto e em mulheres que amamentam irá contribuir para o desenvolvimento saudável do bebê. Entre outros inúmeros benefícios.</p>
        <p class="card-text"><small class="text-muted">Última atualização 3 minutos atrás</small></p>
      </div>  
    </div>  

    <div class="row mt-4">   
      <div class="col-lg-6"> 
         <a href="pag2.php" class="card-link">Alogamento</a> <br>
          <p>Muito consumido por quem busca emagrecer, os sucos detox são grandes aliados da Dieta Detox, que tem como maior objetivo eliminar substâncias prejudiciais ao organismo. Essas substâncias podem vir de agrotóxicos, conservantes, gorduras saturadas, açúcares e sal em excesso e gordura trans.<br> Além disso, estes sucos têm ação antioxidante, ajudando a fortalecer o sistema imunológico e são ricos em fibras, que melhoram o trânsito intestinal. Além de auxiliar na perda de peso, os ingredientes que compõem os sucos são benéficos para a saúde, já que coopera com a limpeza do nosso organismo.</p>
           <p class="card-text"><small class="text-muted">Última atualização 3 minutos atrás</small></p> 
      </div>  
      <div class="col-lg-6 mb-4">   
        <img src="img/alongamento.jpeg" alt="" class="img-fluid">
      </div>    
    </div> 
  </div>
       <!-- Final saude mental-->
   
      <div class="jumbotron bg-success" id="Team">   
    <div class="container">    
      <h2 class="text-center text-white">Programadores</h2>   
      <div class="row mt-5">  
        <div class="col-lg-3 col-sm-6">    
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
              <img src="img/ava2.png" class="img-fluid" style="border-radius: 100px;">
              <h4 class="card-title">Victória Régia</h4>
              <p class="card-text"></p>
            </div>
          </div>
        </div>    

        <div class="col-lg-3 col-sm-6">    
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
              <img src="img/ava2.png" class="img-fluid" style="border-radius: 100px;">
              <h4 class="card-title">Rayane Lopes</h4>
              <p class="card-text"></p>
            </div>
          </div>
        </div>     

        <div class="col-lg-3 col-sm-6">     
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
              <img src="img/ava1.jpg" class="img-fluid" style="border-radius: 100px;">
              <h4 class="card-title">Kennedy Andrade</h4>
              <p class="card-text"></p>
            </div>
          </div>
        </div>     

        <div class="col-lg-3 col-sm-6">       
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
              <img src="img/ava2.png" class="img-fluid" style="border-radius: 100px;">
              <h4 class="card-title">Giselle Rodrigues</h4>
              <h4 class="card-title">Tabatha Elizabeth</h4>
              <p class="card-text"></p>
            </div>
          </div>
        </div>    
      </div>    
    </div> 
  </div> 
      <div class="p-3 mb-2 bg-secondary text-white" .bg-secondary>
<footer class="page-footer font-small stylish-color-dark pt-4" id="page-footer">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-4 mx-auto">

          <!-- Content -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Mind & Health</h5>
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Informações</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Sobre</a>
            </li>
            <li>
              <a href="#!" class="text-white">Artigos</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ebooks</a>
            </li>
            <li>
              <a href="#!" class="text-white">Termos e condições de uso</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Atendimento</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Dúvidas</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ajuda</a>
            </li>
            <li>
              <a href="#!" class="text-white">mindhealth@hotmail.com</a>
            </li>
            <li>
              <a href="#!" class="text-white"></a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-3 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Newsletter</h5>
          <p>Assine nossa newsletter e receba dicas e novidades para uma vida mais saudável</p>
     <!-- Icone Newsletter-->     
    <div class="container">
      <div class="row">
            <div class="thumbnail center well well-sm text-center">
                    <form action="" method="post" role="form">
                        <div class="input-group">
                          <span class="input-group-addon">
                           <!--Aqui deverar ir um icone ou alguma estilização para o newsletter :) -->
                          </span>
                          <input class="form-control" type="text" id="" name="" placeholder="Seu melhor e-mail">
                        </div>
                        <input type="submit" value="Cadastrar" class="btn btn-large btn-primary bg-success"/>
                  </form>
                </div>    
            </div>
  </div>

        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
    <!-- Footer Links -->

    <hr>
            <div class="col-lg-6 col-md-12">
                    <h5 class="white-text text-success">Redes Sociais</h5>
                    <ul class="list-inline redes text-right">
                    <a href="https://www.facebook.com/Mind-Health-1017661845098135/?modal=admin_todo_tour" rel="stylesheet"><i class="fab fa-facebook fa-2x"></i></a>
                    <a href="htthttps://www.instagram.com/mind_healthms/?hl=pt-b" rel="stylesheet"><i class="fab fa-instagram fa-2x"></i></a>
                    <a href=""><i class="fab fa-youtube fa-2x"></i></a>
                    <a href="" rel="stylesheet"><i class="fab fa-twitter fa-2x"></i></a>
                </ul>
        </div>
    <hr>


    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2019 Copyright:
      <a href="https://github.com/KennedyAndrade/Trabalho-Projeto-3/" class="text-success"> Mind & Health</a>
    </div>
    <!-- Copyright -->
</footer>
</div>
<!-- Footer -->

    <!-- Bootstrap JS -->
      
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript">
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            $(".navbar").removeClass("bigMenu");
        }else{
            $(".navbar").addClass("bigMenu");
        }
    });
</script>
</body>
</html>
