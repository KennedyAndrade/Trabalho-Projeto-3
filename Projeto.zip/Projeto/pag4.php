<!doctype html>
<html lang="pt-br">
  <head>
     <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <!--Import Google Icon Font-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  </head>
  <body>
    <?php include_once __DIR__ .'/includes/navbar.php' ?>
    <div class="container pt-5 " id="Courses"> 
    <h2 class="text-center text-success">Saúde Fisica</h2>  
        <div class="text-center">     
        <img src="img/exercicio.jpg" class="img-fluid">
      </div>
    <div class="text-center h5">        
        <p class="card-text">
            <h2 class="font-weight-bold">10 passos para ter o corpo saudável e melhorar a qualidade de vida</h2><br>
            <h3 class="font-weight-bold">Primeiro: Alongamento</h3>
           <p class="font-weight-normal">Quem é obeso sabe da dificuldade de iniciar qualquer programa físico. Portanto o primeiro passo foi iniciar com o princípio básico de toda a atividade física, O ALONGAMENTO.
               Estabeleci uma carga mínima de cinco minutos diários, para não perder a motivação. Por um mês fiz alongamento dos membros inferiores e superiores e, ao final do tempo previsto o meu estado anímico melhorou consideravelmente e a musculatura já não reagia ao exercício.<br></p>
        
             <h3 class="font-weight-bold">Segundo: Caminhada</h3>
         <p class="font-weight-normal">Mais motivado resolvi dar o segundo passo em busca da minha qualidade de vida praticando uma atividade física. Caminhava três vezes por semana em uma intensidade moderada durante trinta minutos, sem abandonar o alongamento, antes e depois do exercício.
É importante, nesta fase, estabelecer um horário que seja mais prático, dependendo das suas atividades diárias. O horário, escolhido por mim, foi o das 19 horas, quando me desobrigava dos meus compromissos diários.
        No final do segundo mês me sentia mais leve.<br></p>
        
            <h3 class="font-weight-bold">Terceiro: Respiração</h3>
           <p class="font-weight-normal">Passados dois meses, me sentindo muito melhor, fui para o terceiro passo. Como sou ansioso a minha pressão continuava alta, e para relaxar adotei técnicas de respiração.
Aprendi a respirar com o diafragma. Com cinco minutos, por dia, usando esta técnica de respiração, em menos de um mês, minha ansiedade já estava bem controlada e minha pressão mais baixa, quase dentro da normalidade.<br></p>
           <h3 class="font-weight-bold">Quarto: Dieta</h3>
          <p class="font-weight-normal">Menos ansioso e com uma melhor auto-estima, decidi então dar o quarto passo: melhorar a minha alimentação. Fiz uma dieta nada radical onde evitava frituras, gorduras e embutidos, podendo escolher um dia por semana para poder comer o que quisesse, pois apesar de saber que não faz bem comer este tipo de alimento, gosto muito e muitas vezes comemos também para socializar com amigos ou parentes.<br>Com a redução de frituras gorduras e embutidos, melhorei muito minha parte intestinal, pois sempre tive muitos problemas de prisão-de-ventre e cólicas abdominais.<br>Minha alimentação estava boa, mas faltava algo que eu não gostava mesmo sabendo de sua grande importância para uma alimentação saudável.<br>
    
       </p>
          <h3 class="font-weight-bold">Quinto: Alimentação saudável (Saladas e verduras)</h3>
        <p class="font-weight-normal"> Este, confesso, não foi fácil. Geralmente, quem tem problema de peso, abdicam das comidas saudáveis para ingerir os alimentos que o atraem, logicamente os mais saturados em gorduras. Mesmo não gostando ingeria salada e verduras todos os dias, antes de comer os pratos mais calóricos.<br>
        Passada a dificuldade inicial, pois em minha vida toda nunca tinha comido salada, fui me habituando e senti os benefícios desta decisão principalmente na parte intestinal e também na dieta de emagrecimento, pois comendo salada eliminava espaço para os demais alimentos.</p>
        <div class="text-center">     
                <img src="img/emagrecer.jpg" class="img-fluid ">
            </div>
          <h3 class="font-weight-bold">Sexto: Frutas</h3>
        <p class="font-weight-normal">Para a minha alimentação ficar perto da perfeição faltava os dois seguintes passos. O sexto passo foi o de me conscientizar a comer frutas entre as refeições ao invés de produtos industrializados e repletos de gordura trans e sódio. A pressão melhorou e o peso diminuiu, para a minha alegria.<br>
            "Sua meta tem que ser sempre a sua saúde, o seu bem-estar e a sua auto-estima."<br>
        </p>
        
          <h3 class="font-weight-bold">Sétimo: Água.</h3>
        <p class="font-weight-normal">Quando passei a tomar cerca de dois litros de água por dia, mais a ingestão de frutas, saladas e verduras, as cólicas abdominais, azia e prisão de ventre desapareceram e regularizei totalmente o meu intestino.<br>
        No sétimo passo minha vida tinha mudado da água para o vinho, pois não sentia mais dores musculares, minha pressão estava controlada, meu intestino funcionava regularmente e já havia perdido mais de trinta e cinco quilos, me sentindo muito melhor minha auto estima tinha voltado e eu não sabia mais o que era depressão.
        </p>
            
          <h3 class="font-weight-bold">Oitavo: Chá verde</h3>
        <p class="font-weight-normal">Beber todos dos dias de dois a três copos de chá verde por dia, que representa o equivalente a meio litro de água.<br>
        O chá verde auxilia na perda de peso, diminuição das taxas de colesterol, controla a pressão arterial, ativa o sistema imunológico, reduz o risco de artrose, aterosclerose dentre outras doenças degenerativas, tem ótima ação cicatrizante por uso tópico.</p>
        
          <h3 class="font-weight-bold">Nono: Fibras</h3>
        <p class="font-weight-normal">Juntamente com o oitavo passo, passei para o nono, a ingestão de fibras na minha alimentação.<br>Além de regularizar o intestino, as fibras previnem muitos tipos de câncer do aparelho digestivo e são muito úteis no processo de emagrecimento.
          </p>
          <h3 class="font-weight-bold">Décimo: Perseverança</h3>
        <p class="font-weight-normal">Meus amigos o último passo é o mais importante, o mais difícil e o mais complicado de qualquer projeto, quer seja alimentar, físico ou intelectual a: PERSEVERANÇA.<br>Sem isto não se chega a lugar algum. Não se atinge os objetivos desejados. Você tem que por na cabeça aonde quer chegar, não importam as dificuldades, os sacrifícios e o desânimo, que certamente vai acontecer, pois não há vitória sem luta. Não esmoreça.<br>
        Dê o primeiro passo e ele o levará ao final do seu objetivo e, no nosso caso, o objetivo é o mais importante do mundo: a sua saúde, o seu bem-estar e a sua auto-estima.<br>Caros amigos, como poderão notar todos os passos podem ser seguidos por qualquer pessoa e de qualquer nível social, pois técnicas de respiração, alongamentos, caminhadas e a ingestão de saladas, frutas, chá verde e fibras só dependem da nossa força de vontade.</p><br>
      </p>
    <div class="card font-weight-bold">
          <div class="card-header">
           Fontes consultadas:
          </div>
        <div class="card-body">
            <blockquote class="blockquote mb-0">
                <footer class="blockquote-footer"> Escrito por Flávio Bueno: Redação Minha Vida<cite title="Source Title">,Educação Física </cite>
                 <a href="https://www.minhavida.com.br/fitness/materias/11402-10-passos-para-ter-o-corpo-saudavel-e-melhorar-a-qualidade-de-vida">https://www.minhavida.com.br/fitness/materias/11402-10-passos-para-ter-o-corpo-saudavel-e-melhorar-a-qualidade-de-vida</a></footer>
            </blockquote>
        </div>
    </div>
  </div>     
</div>
       <div class="p-3 mb-2 bg-dark text-white" id="page-footer">
<footer class="page-footer font-small stylish-color-dark pt-4">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-4 mx-auto">

          <!-- Content -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Mind & Health</h5>
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Informações</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Sobre</a>
            </li>
            <li>
              <a href="#!" class="text-white">Artigos</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ebooks</a>
            </li>
            <li>
              <a href="#!" class="text-white">Termos e condições de uso</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Atendimento</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Dúvidas</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ajuda</a>
            </li>
            <li>
              <a href="#!" class="text-white">mindhealth@hotmail.com</a>
            </li>
            <li>
              <a href="#!" class="text-white"></a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-3 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Newsletter</h5>
          <p>Assine nossa newsletter e receba dicas e novidades para uma vida mais saudável</p>
     <!-- Icone Newsletter-->     
    <div class="container">
      <div class="row">
            <div class="thumbnail center well well-sm text-center">
                    <form action="" method="post" role="form">
                        <div class="input-group">
                          <span class="input-group-addon">
                           <!--Aqui deverar ir um icone ou alguma estilização para o newsletter :) -->
                          </span>
                          <input class="form-control" type="text" id="" name="" placeholder="Seu melhor e-mail">
                        </div>
                        <input type="submit" value="Cadastrar" class="btn btn-large btn-primary bg-success"/>
                  </form>
                </div>    
            </div>
  </div>

        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
    <!-- Footer Links -->

    <hr>
            <div class="col-lg-6 col-md-12">
                    <h5 class="white-text text-success">Redes Sociais</h5>
                    <ul class="list-inline redes text-right">
                    <a href="https://www.facebook.com/Mind-Health-1017661845098135/?modal=admin_todo_tour" rel="stylesheet"><i class="fab fa-facebook fa-2x"></i></a>
                    <a href="htthttps://www.instagram.com/mind_healthms/?hl=pt-b" rel="stylesheet"><i class="fab fa-instagram fa-2x"></i></a>
                    <a href=""><i class="fab fa-youtube fa-2x"></i></a>
                    <a href="" rel="stylesheet"><i class="fab fa-twitter fa-2x"></i></a>
                </ul>
        </div>
    <hr>


    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2019 Copyright:
      <a href="https://github.com/KennedyAndrade/Trabalho-Projeto-3/" class="text-success"> Mind & Health</a>
    </div>
    <!-- Copyright -->
</footer>
</div>
<!-- Footer -->
      <!-- Bootstrap JS -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>