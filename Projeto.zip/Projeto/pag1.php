<!doctype html>
<html lang="pt-br">
  <head>
     <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <!--Import Google Icon Font-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  </head>
  <body>
    <?php include_once __DIR__ .'/includes/navbar.php' ?>
    <div class="container pt-5 " id="Courses"> 
    <h2 class="text-center text-success">NUTRIÇÃO</h2>  
    <div class="text-center">        
      <div class="text-center">     
        <img src="img/curiosidade.jpg" class="img-fluid">
      </div>
        <p class="card-text">Ter uma alimentação saudável é fundamental para que as funções do organismo funcionem de foma equilibrada.De forma prática, uma alimentação saudável é aquela composta por todos os macro e micronutrientes.<br>
            <h3>Os Macro e Micronutrientes.</h3>
           Os macronutrientes são os carboidratos (pães, massas e batatas, entre outros), gorduras (como os óleos, as oleaginosas, abacate e outros) e proteínas (peixes, ovos, carnes vermelhas, carne de frango, entre outros). Enquanto os micronutrientes são as vitaminas e minerais, que estão presentes nos mais diversos alimentos, como frutas, verduras, legumes, entre outros. As fibras, a parte não digerível do alimento vegetal, a qual resiste à digestão e à absorção intestinal, com fermentação completa ou parcial no intestino grosso, também são essenciais para a alimentação saudável e estão presentes nos alimentos integrais, nas frutas e verduras. Uma alimentação composta por estes nutrientes de forma equilibrada costuma ser bem variada, não tem exageros e não segue nenhum tipo de modismo.<br>
            Ter uma alimentação saudável proporciona uma série de benefícios para as pessoas. Ela contribui para a melhora no sistema imunológico, na qualidade de sono, no trânsito intestinal, no humor, na capacidade de concentração e pode contribuir até mesmo para a perda de peso. Em gestantes, ela é essencial para o bom desenvolvimento do feto e em mulheres que amamentam irá contribuir para o desenvolvimento saudável do bebê. Entre outros inúmeros benefícios.
          <p>Ter uma alimentação saudável proporciona uma série de benefícios para as pessoas. Ela contribui para a melhora no sistema imunológico, na qualidade de sono, no trânsito intestinal, no humor, na capacidade de concentração e pode contribuir até mesmo para a perda de peso. Em gestantes, ela é essencial para o bom desenvolvimento do feto e em mulheres que amamentam irá contribuir para o desenvolvimento saudável do bebê. Entre outros inúmeros benefícios. <br>
             <h3>Pirâmide alimentar brasileira</h3>
          A pirâmide alimentar foi adaptada para a população brasileira em 1999 pela nutricionista sanitarista Sonia Tucunduva Philippi, professora da Universidade de São Paulo. Esta pirâmide foi criada com o objetivo de facilitar o entendimento do público sobre quais os alimentos que devem ser mais ingeridos e quais devem ter um consumo menor.
         A adaptação envolveu basicamente trocar alguns alimentos que não eram tão comuns no Brasil por outros nutricionalmente equivalentes, mas que eram ingeridos com maior frequência pelos brasileiros.
         Os alimentos presentes na base da pirâmide são aqueles que devem ser mais consumidos, quanto mais para cima o alimento estiver localizado, em menores quantidades ele deve ser ingerido. A orientação de acordo com a pirâmide é ingerir 6 porções ao dia de carboidratos, como pães, arroz, batata, mandioca e outros, 3 poções de legumes e verduras, 3 de frutas, 3 de laticínios, como queijos, leite e iogurte, uma de carnes e ovos, uma de feijão e outras leguminosas, uma de óleos e outras gorduras e uma de açúcares e doces.<br>
         <h4>A seguir confira a pirâmide alimentar brasileira:</h4> <br>
          <div class="text-center">   
        <img src="img/piramide-nova.jpg" alt="" class="img-fluid">
            <p>Fonte: Redesenho da Pirâmide Alimentar Brasileira para uma alimentação saudável</p>
      </div> 
           <h3>Os macronutrientes</h3>
          <p>Os macronutrientes consistem nas gorduras, carboidratos e proteínas. Os carboidratos são a principal fonte de energia do corpo, eles possuem 4 calorias por grama e se dividem entre simples e complexos. <br>
        A digestão e absorção dos carboidratos simples acontece rapidamente levando a um aumento dos níveis de glicose no sangue (glicemia). Exemplos de alimentos que são fontes de carboidratos simples: frutas, mel, xarope de milho, açúcar. O excesso dos carboidratos simples pode favorecer problemas de saúde como diabetes.<br>
        Já os carboidratos complexos possuem estrutura química maior (polissacarídeos). Por ser uma molécula maior são digeridos e absorvidos mais lentamente, ocasionando aumento gradual da glicemia. Exemplos de alimentos fontes de carboidratos deste grupo: arroz integral, pão integral, batata doce, massa integral. Estes carboidratos complexos são ricos em fibras e por isso contribuem para a melhora no trânsito intestinal, previnem o diabetes, ajudam na perda de peso, controle do nível de colesterol, entre outros.<br>
        Outro macronutriente é a proteína. Ela possui quatro calorias por grama e tem como uma de suas principais funções reparar as microlesões que ocorrem como um processo fisiológico normal quando se pratica atividade física e proporcionar a sua regeneração e formação de novas células musculares.<br>
        As proteínas podem ser encontradas em alimentos de origem animal, como carnes vermelhas, peixes, aves, laticínios e ovos. Elas também estão presentes nos alimentos de origem vegetal, especialmente leguminosas como feijão e soja.<br>
        O outro macronutriente é a gordura e possui 9 calorias por gramas. Elas se dividem entre gorduras monoinsaturadas, poli-insaturadas e saturadas. As gorduras proporcionam saciedade e algumas delas proporcionam benefícios para o cérebro. As gorduras poli-insaturadas são encontradas em alimentos como a chia, a linhaça e peixes de água fria, salmão e sardinha por exemplo. Já as monoinsaturadas estão presentes em óleos, como o azeite e no abacate.
       </p>
          <h3>Quantidades recomendadas de macronutrientes</h3>
        <p> A recomendação é que uma alimentação saudável seja composta de 40 a 55% de carboidratos, 15 a no máximo 30% de proteínas, sendo metade de origem animal e outra vegetal, e entre 25 e 30% de gorduras, sendo um terço de saturadas, um terço de poli-insaturadas e um terço de monoinsaturadas.</p>
          <h3>Macronutrientes para priorizar</h3>
        <p> Os carboidratos complexos, aqueles em que o açúcar demora mais para ser absorvido no sangue, e menor carga glicêmica, quantidade de açúcar presente no alimento, são os que devem estar presentes com maior frequência em uma alimentação saudável. As frutas, especialmente quando ingeridas com casca, e os alimentos integrais costumam ter estas características.
        Quanto às proteínas, a recomendação é ingerir tanto aquelas de origem vegetal, como a soja e o feijão, quanto às de origem animal. Porém, uma pessoa consegue manter uma dieta vegetariana e ainda assim ser saudável. Fontes de proteínas de origem animal que vale a pena investir são aquelas com menor concentração de gorduras saturadas como os peixes, as aves, os ovos e o leite semi-desnatado. Quanto aquelas de origem vegetal, todas parecem ser boas alternativas, como o feijão, a soja, a lentilha, o grão de bico e a quinoa.<br>
        Quanto às gorduras, aquelas insaturadas são boas alternativas para a saúde. Vale investir em fontes de ômega 3 como o salmão, a sardinha e outros peixes de águas frias, a chia e a linhaça. Alimentos ricos em gorduras monoinsaturadas como o abacate e o azeite também são ótimas opções.</p>
          <h3>Macronutrientes para evitar</h3>
        <p>É importante reduzir o consumo de fontes de carboidratos com alto índice e taxa glicêmica, como o pão branco, a batata, a massa e o arroz branco. Isto porque eles podem levar a picos de insulina que em excesso favorecem desde o ganho de peso até o diabetes.<br>
        Quanto à proteína, é importante não abusar do consumo da carne vermelha. Ingerir cerca de 300 gramas deste alimento por semana já é o suficiente. O excesso de carne vermelha leva ao maior consumo de gorduras saturadas que aumenta o risco de problemas cardiovasculares, entre outros.</p>
          <div class="text-center">     
                <img src="img/macarrao.jpg" class="img-fluid ">
            </div>
          <h3>Micronutrientes</h3>
        <p>Entre os micronutrientes temos os minerais e as vitaminas, o que resulta em dezenas de substâncias essenciais para a manutenção da vida. Alguns bons exemplos de vitaminas são: vitamina A, importante para a visão e crescimento e que é encontrada em ovos, cereais fortificados, leite, cenoura, entre outros, vitaminas do complexo B, grandes aliadas do cérebro e que são encontradas principalmente em carnes, leite e ovos, e vitamina C, que melhora a imunidade e pode ser encontrada nas frutas como kiwi, laranja e acerola.
        Quanto aos minerais, eles se dividem entre macromineais, que precisamos ingerir em grandes quantidades, como o cálcio, e os elementos traços, que precisamos de pequenas porções, como o boro. Exemplos de macrominerais são o ferro, que previne anemia, é bom para o coração e pode ser encontrado em carnes, e o cálcio, aliado dos ossos e dentes que está presente principalmente nos laticínios.
        Como existem diversos micronutrientes, a melhor maneira de saber que está ingerindo quantidades suficientes deles é manter sempre uma grande variedade na dieta. Procure consumir todos os grupos alimentares e seguir o conceito de variabilidade alimentar que sugere que a sua dieta abranja ao menos 30 alimentos. Produtos alimentares, como embutidos, bolachas recheadas, entre outros, não entram na conta.</p>
          <h3>Atitudes que garantem a alimentação saudável</h3>
        <p>Para ter uma alimentação saudável é importante que ela seja muito variada e conte com todos os grupos alimentares. Seguir o conceito de variabilidade alimentar, que sugere que a sua dieta abranja ao menos 30 alimentos, é uma boa ideia. Lembrando que produtos alimentares, como embutidos, bolachas recheadas, entre outros, não entram na conta.<br>
        Outro cuidado importante está na escolha dos alimentos. Em relação aos carboidratos é importante priorizar os complexos, como pães integrais, arroz e massas integrais. Já quando falamos de gorduras, as fontes de gorduras insaturadas devem ser ingeridas em maior quantidade, como as oleaginosas, o azeite, o abacate, o salmão e a chia. Quanto às proteínas, vale priorizar as versões magras, como peixes, aves, carnes vermelhas com pouca gordura e aquelas de origem vegetal, como feijão, lentilhas e soja.
          </p>
          <h3>O papel da água</h3>
        <p>A água é essencial para o transporte de nutrientes no organismo e a hidratação. A orientação é ingerir 30 ml de água por quilo de peso no dia, o que equivale a cerca de dois ou três litros de água por dia. A água não deve ser substituída por refrigerantes, sucos, especialmente os industrializados, e muito menos bebidas alcoólicas.</p><br>
    <div class="card">
          <div class="card-header">
           Fontes consultadas:
          </div>
        <div class="card-body">
            <blockquote class="blockquote mb-0">
                <footer class="blockquote-footer"> Escrito por Bruna Stuppiello: Redação Minha Vida<cite title="Source Title">, Nutrólogo Roberto Navarro Nutricionista Rosana Farah, professora da Universidade Presbiteriana Mackenzie e membro da clínica Ávvia Medicina e Nutrição.</cite></footer>
            </blockquote>
        </div>
    </div>
  </div>     
</div>
       <div class="p-3 mb-2 bg-secondary text-white" id="page-footer">
<footer class="page-footer font-small stylish-color-dark pt-4">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-4 mx-auto">

          <!-- Content -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Mind & Health</h5>
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Informações</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Sobre</a>
            </li>
            <li>
              <a href="#!" class="text-white">Artigos</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ebooks</a>
            </li>
            <li>
              <a href="#!" class="text-white">Termos e condições de uso</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Atendimento</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Dúvidas</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ajuda</a>
            </li>
            <li>
              <a href="#!" class="text-white">mindhealth@hotmail.com</a>
            </li>
            <li>
              <a href="#!" class="text-white"></a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-3 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Newsletter</h5>
          <p>Assine nossa newsletter e receba dicas e novidades para uma vida mais saudável</p>
     <!-- Icone Newsletter-->     
    <div class="container">
      <div class="row">
            <div class="thumbnail center well well-sm text-center">
                    <form action="" method="post" role="form">
                        <div class="input-group">
                          <span class="input-group-addon">
                           <!--Aqui deverar ir um icone ou alguma estilização para o newsletter :) -->
                          </span>
                          <input class="form-control" type="text" id="" name="" placeholder="Seu melhor e-mail">
                        </div>
                        <input type="submit" value="Cadastrar" class="btn btn-large btn-primary bg-success"/>
                  </form>
                </div>    
            </div>
  </div>

        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
    <!-- Footer Links -->

    <hr>
            <div class="col-lg-6 col-md-12">
                    <h5 class="white-text text-success">Redes Sociais</h5>
                    <ul class="list-inline redes text-right">
                    <a href="https://www.facebook.com/Mind-Health-1017661845098135/?modal=admin_todo_tour" rel="stylesheet"><i class="fab fa-facebook fa-2x"></i></a>
                    <a href="htthttps://www.instagram.com/mind_healthms/?hl=pt-b" rel="stylesheet"><i class="fab fa-instagram fa-2x"></i></a>
                    <a href=""><i class="fab fa-youtube fa-2x"></i></a>
                    <a href="" rel="stylesheet"><i class="fab fa-twitter fa-2x"></i></a>
                </ul>
        </div>
    <hr>


    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2019 Copyright:
      <a href="https://github.com/KennedyAndrade/Trabalho-Projeto-3/" class="text-success"> Mind & Health</a>
    </div>
    <!-- Copyright -->
</footer>
</div>
<!-- Footer -->
      <!-- Bootstrap JS -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript">
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            $(".navbar").removeClass("bigMenu");
        }else{
            $(".navbar").addClass("bigMenu");
        }
    });
</script>
  </body>
</html>