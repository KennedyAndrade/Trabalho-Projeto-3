<!doctype html>
<html lang="pt-br">
  <head>
      <!--Meta Tags-->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mind & Health - Saúde Física e Mental</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <!--Import Google Icon Font-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
      <!--Favicon.ico Icone do Site-->
    <link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
    <link rel="manifest" href="favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
  </head>
  <body>
    <?php include_once __DIR__ .'/includes/navbar.php' ?>
    <div class="container pt-5 " id="Courses"> 
    <h2 class="text-center text-success">SAÚDE MENTAL</h2>  
        <div class="text-center">     
        <img src="img/amizade.jpg" class="img-fluid">
      </div>
    <div class="text-center h5">        
            <h3 class="font-weight-bold"> Modelo de atenção em saúde
mental</h3>
          
        <p class="font-weight-normal">Todo modelo de atenção em saúde mental estabelece intermediações
        entre o aspecto técnico e o político e nele devem estar presentes os interesses e as necessidades da sociedade, o saber técnico, as diretrizes
        políticas e os modos de gestão dos sistemas públicos. Isso implica um
        processo de contínua criatividade voltado para as necessidades mutáveis
        dos usuários, para as características sociorregionais e para o oferecimento
        dos serviços. Para Merhy (1991, p. 84), “ao se falar de modelo assistencial estamos falando tanto da organização da produção de serviços de
        saúde a partir de um determinado arranjo de saberes da área, bem como
        de projetos de construção de ações sociais específicas, como estratégia
        política de determinados agrupamentos sociais”.
        É por meio da definição de um modelo assistencial que elaboramos as
        ações de saúde a serem desenvolvidas, delimitamos o seu universo de
        atendimento, traçamos o perfil dos profissionais e os objetivos a serem
        alcançados. O modelo é, portanto, a mola mestra para a organização e
        direcionamento das práticas em saúde.
        Em saúde mental precisamos saber, por exemplo, se a construção do
        projeto terapêutico será centrada nas necessidades do usuário levando
        em conta sua opinião e de seus familiares, se a prioridade de atendimento
        será definida pela gravidade e não pela ordem de chegada, se há o compromisso do município de promover ações intersetoriais possibilitando
        novas formas de inserção sociofamiliar, etc. Estes são alguns aspectos
        que caracterizam o modelo proposto pelo Sistema Único de Saúde (SUS)
        e que, também, contemplam os princípios propostos pelo Movimento da
        Reforma Psiquiátrica Brasileira.
        <br>
        Na sociedade contemporânea, torna-se cada vez mais difícil praticar a
        ciência na certeza da estabilidade e do enquadramento. Somos, cada vez
        mais, propensos a entender os fenômenos de nossa vida cotidiana como
        algo em constante transformação e movimento.
        Nenhum fenômeno, por menor que seja, tem sua origem definida por
        uma única matriz. Compreender o mundo atual nos direciona, com mais
        frequência, a percorrer caminhos diversos: o social, cultural, biológico,
        econômico e psíquico. Entretanto, ainda existe a tendência a buscarmos a
        causa biológica como o fator desencadeante da maioria das doenças em
        detrimento de outras causas de igual importância. Mas podemos afirmar
        que qualquer doença só pode ser entendida quando inserida na sociedade
        em que ocorre, considerando a classe social do indivíduo.
        Não podemos reduzir a saúde mental à ausência de transtornos
        psíquicos. Ela vai mais além. Ela fornece a nossa identidade social, a nossa possibilidade de transitar com autonomia pela vida. Nesse sentido, Merhy (2002, p. 40) afirma que a saúde “é um valor de uso para o usuário, que a representa como algo útil por lhe permitir estar no mundo e poder vivê-lo de um modo autodeterminado e dentro de seu universo de representações”.Todo estado de saúde e doença é determinado, portanto, pela cultura na qual o sujeito se insere. Para Foucault (1978, p. 186), “o louco não pode ser
        louco para si mesmo, mas apenas aos olhos de um terceiro que, somente este, pode distinguir o exercício da razão da própria razão”. Portanto, a maneira como entendemos e lidamos com a saúde e a doença mental
        está inscrita no mundo social-histórico e é definida pela cultura e legitimada pelo senso comum. Nas relações que o sujeito mantém com o seu grupo e classe social é construída uma rede de significados que apontam a saúde e a doença como construções de sua cultura.</p>
          <div class="text-center">     
           <img src="img/mental.jpg" class="img-fluid">
         </div>
             <h3 class="">Cuidado em saúde mental</h3>
        <p class="font-weight-normal">Consideramos fundamental, neste momento, discutir as várias concepções de cuidado que existem em nossos serviços de saúde.
        Alguns dicionários de filologia informam que a origem da palavra cuidado é o latim cura, utilizada para descrever um contexto de relações de
        amor e amizade marcadas por atitudes de atenção, desvelo e preocupação
        com um objeto ou pessoa querida. Outros estudiosos derivam a palavra
        cuidado de cogitare-cogitatus e de sua corruptela coyedar, coidar, cuidar,
        que tem o mesmo significado de cura: pensar, colocar atenção, mostrar
        interesse, desvelo e preocupação. Para Boff (2000, p. 91-2), o “cuidado
        inclui duas significações básicas, intimamente ligadas entre si. A primeira,
        a atitude de desvelo, de solicitude e de atenção para com o outro. A segunda, de preocupação e de inquietação, porque a pessoa que tem cuidado se
        sente envolvida e afetivamente ligada ao outro”.<br>
        Neste sentido, entendemos que a palavra cuidado carrega duplo significado. “Cuidado, no sentido de alerta, o sinal vermelho do semáforo.
        Perigo de, na relação com o outro, no movimento de sair de si mesmo, ir
        ao encontro do outro, perder-se”. Um outro sentido desloca a palavra cuidado para a maternagem, para o aconchego do colo, da relação amorosa/
        afetiva, do acolhimento que, no geral, só um ser humano pode dispensar
        ao outro” (ROSA, 2001, p. 56).
        O ato de cuidar adquire características diferentes em cada sociedade e
        é determinado por fatores sociais, culturais e econômicos. Esses fatores
        vão definir os valores e as condições em que se processa o ato cuidador.
        Podemos afirmar que cuidar é basicamente um ato criador, atento, perspicaz às necessidades e singularidades de quem o demanda. O cuidado é
        único e é sempre dirigido a alguém. Não existem fórmulas mágicas para o
        ato do cuidar e sim a invenção, o jogo de cintura, a busca de possibilidades
        várias. No cuidar avista-se o outro. <br>
        A assistência à doença mental, em toda a sua história, sempre registrou
        a impossibilidade da família estar junto, conviver e cuidar do doente mental. Tratar do doente mental significou, durante décadas, o afastamento do
        convívio social e familiar. Transformar, recriar as relações existentes entre a
        família, a sociedade e o doente mental não é tarefa das mais fáceis. Existe
        o pronto, o universalmente aceito, a delegação do cuidado a outrem, que
        revelam as incapacidades de lidar com a loucura, de aceitar novos desafios
        e de se aventurar em caminhos não trilhados.
        Para cuidar não precisamos isolar, retirar o sujeito de seu âmbito familiar
        e social. O ato cuidador, em nosso entender, vai mais além. Ele faz emergir
        a capacidade criadora existente em cada um, ressalta a disponibilidade
        em se lançar, em criar novas maneiras de conviver com o outro em suas
        diferenças. Isto não significa que no manejo da crise possamos prescindir
        de ajuda especializada e acesso aos serviços de saúde. Eles são, sem
        dúvida, o grande suporte que o familiar necessita para poder cuidar.A assistência à doença mental, em toda a sua história, sempre registrou
        a impossibilidade da família estar junto, conviver e cuidar do doente mental. Tratar do doente mental significou, durante décadas, o afastamento do
        convívio social e familiar. Transformar, recriar as relações existentes entre a
        família, a sociedade e o doente mental não é tarefa das mais fáceis. Existe
        o pronto, o universalmente aceito, a delegação do cuidado a outrem, que
        revelam as incapacidades de lidar com a loucura, de aceitar novos desafios
        e de se aventurar em caminhos não trilhados.
        Para cuidar não precisamos isolar, retirar o sujeito de seu âmbito familiar
        e social. O ato cuidador, em nosso entender, vai mais além. Ele faz emergir
        a capacidade criadora existente em cada um, ressalta a disponibilidade
        em se lançar, em criar novas maneiras de conviver com o outro em suas
        diferenças. Isto não significa que no manejo da crise possamos prescindir
        de ajuda especializada e acesso aos serviços de saúde. Eles são, sem
        dúvida, o grande suporte que o familiar necessita para poder cuidar.</p>
         <div class="text-center">     
           <img src="img/saudemental.jpg" class="img-fluid">
         </div>
        <p class="font-weight-normal">A forma como o serviço se organiza para responder às necessidades
        do usuário está diretamente relacionada à sua qualidade. Saraceno (1999,
        p. 95) define um serviço de alta qualidade como aquele “que se ocupa
        de todos os pacientes que a ele se referem e que oferece reabilitação a
        todos os pacientes que dele possam se beneficiar”.
        Não podemos reduzir a amplitude de um serviço a um local físico e aos seus
        profissionais, mas a toda a gama de oportunidades e lugares que favoreçam a
        reabilitação do paciente. Um dos lugares privilegiados no intercâmbio com os
        serviços é a comunidade e dela fazem parte a família, as associações, os sindicatos, as igrejas, etc. A comunidade é, portanto, fonte de recursos humanos e
        materiais, lugar capaz de produzir sentido e estimular as trocas.<br>
        As relações estratégicas mantidas entre o serviço e a comunidade
        podem ser pautadas pela negação (a comunidade não existe), pela paranoia
        (a comunidade são os inimigos que nos assediam), pela sedução e busca
        de consenso (a comunidade é tudo aquilo e somente aquilo que me aceita
        da forma como sou e me aprova) e pela interação/integração (a comunidade é uma realidade complexa e exprime interesses contrastantes). Visto que a família é parte integrante da comunidade, o serviço geralmente usa com a família as mesmas estratégias utilizadas com a comunidade. Desta maneira, a família pode se tornar não só a protagonista das estratégias de cuidado e de reabilitação propostas pelo serviço, mas também uma protagonista conflituosa dessas mesmas estratégias.</p>
    <div class="card font-weight-bold">
          <div class="card-header">
           Fonte consultada:
          </div>
        <div class="card-body">
            <blockquote class="blockquote mb-0">
                <footer class="blockquote-footer"> Escrito por Núcleo de Educação em Saúde Coletiva da Faculdade de Medicina/UFMG (Nescon)<cite title="Source Title">, Paula Cambraia de Mendonça Vianna e Alexandre de Araújo Pereira</cite>
            <a href="https://www.nescon.medicina.ufmg.br/biblioteca/imagem/1730.pdf" target="_blank">https://www.nescon.medicina.ufmg.br/biblioteca/imagem/1730.pdf</a></footer>
            </blockquote>
        </div>
    </div>
  </div>     
</div>
       <div class="p-3 mb-2 bg-dark text-white" id="page-footer">
<footer class="page-footer font-small stylish-color-dark pt-4">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-4 mx-auto">

          <!-- Content -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Mind & Health</h5>
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Informações</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Sobre</a>
            </li>
            <li>
              <a href="#!" class="text-white">Artigos</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ebooks</a>
            </li>
            <li>
              <a href="#!" class="text-white">Termos e condições de uso</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Atendimento</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Dúvidas</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ajuda</a>
            </li>
            <li>
              <a href="#!" class="text-white">mindhealth@hotmail.com</a>
            </li>
            <li>
              <a href="#!" class="text-white"></a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-3 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Newsletter</h5>
          <p>Assine nossa newsletter e receba dicas e novidades para uma vida mais saudável</p>
     <!-- Icone Newsletter-->     
    <div class="container">
      <div class="row">
            <div class="thumbnail center well well-sm text-center">
                    <form action="" method="post" role="form">
                        <div class="input-group">
                          <span class="input-group-addon">
                           <!--Aqui deverar ir um icone ou alguma estilização para o newsletter :) -->
                          </span>
                          <input class="form-control" type="text" id="" name="" placeholder="Seu melhor e-mail">
                        </div>
                        <input type="submit" value="Cadastrar" class="btn btn-large btn-primary bg-success"/>
                  </form>
                </div>    
            </div>
  </div>

        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
    <!-- Footer Links -->

    <hr>
            <div class="col-lg-6 col-md-12">
                    <h5 class="white-text text-success">Redes Sociais</h5>
                    <ul class="list-inline redes text-right">
                    <a href="https://www.facebook.com/Mind-Health-1017661845098135/?modal=admin_todo_tour" rel="stylesheet"><i class="fab fa-facebook fa-2x"></i></a>
                    <a href="htthttps://www.instagram.com/mind_healthms/?hl=pt-b" rel="stylesheet"><i class="fab fa-instagram fa-2x"></i></a>
                    <a href=""><i class="fab fa-youtube fa-2x"></i></a>
                    <a href="" rel="stylesheet"><i class="fab fa-twitter fa-2x"></i></a>
                </ul>
        </div>
    <hr>


    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2019 Copyright:
      <a href="https://github.com/KennedyAndrade/Trabalho-Projeto-3/" class="text-success"> Mind & Health</a>
    </div>
    <!-- Copyright -->
</footer>
</div>
<!-- Footer -->
      <!-- Bootstrap JS -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>