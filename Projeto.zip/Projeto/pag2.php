<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <!--Import Google Icon Font-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
      <!--Favicon.ico Icone do Site-->
    <link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
    <link rel="manifest" href="favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
  </head>
  <body>
       <?php include_once __DIR__ .'/includes/navbar.php' ?>
                
<!--https://www.minhavida.com.br/alimentacao/tudo-sobre/32858-suco-detox-->
    <div class="container pt-5 " id="Courses"> 
    <h2 class="text-center text-success">NUTRIÇÃO</h2>
      <div class="text-center">            
        <img src="img/detoxVerde.jpg" class="img-fluid">
      </div>
    <div class="row mt-4 text-center">        
        <p class="card-text font-weight-bold mt-3 mb-4 text-success font-italic"><br>
            Muito consumido por quem busca emagrecer, os sucos detox são grandes aliados da Dieta Detox, que tem como maior objetivo eliminar substâncias prejudiciais ao organismo. Essas substâncias podem vir de agrotóxicos, conservantes, gorduras saturadas, açúcares e sal em excesso e gordura trans.<br>
            Além disso, estes sucos têm ação antioxidante, ajudando a fortalecer o sistema imunológico e são ricos em fibras, que melhoram o trânsito intestinal. Além de auxiliar na perda de peso, os ingredientes que compõem os sucos são benéficos para a saúde, já que coopera com a limpeza do nosso organismo.</p><br> 
        
         </div>
</div>
         <div class="text-justify"> 
         <h4 class="font-weight-bold text-center">1. Suco detox de cenoura, repolho e maçã</h4>
             <p class="font-weight-bold text-center">Ingredientes:</p><br> 
             <p class="h5 text-center">5 cenouras, ¼ de repolho verde pequeno e ½ maçã.<br>5 cenouras, ¼ de repolho verde pequeno e ½ maçã.</p>
             <p class="font-weight-bold text-center">Modo de preparo:</p><br> 
             <p class="h5 text-center">Bata os ingredientes no liquidificador com meio litro de água. Depois, acrescente mais, aproximadamente, 1,5 litros de água. Mexa bem e adoce a gosto.</p><br>
        
         <h4 class="font-weight-bold text-center">2. Suco de couve, cenoura, salsinha e maçã</h4>
          <p class="font-weight-bold text-center">Ingredientes:</p> 
             <p class="h5 text-center">5 a 6 cenouras, 4 folhas de couve, 4 galhinhos de salsinha e ½ maçã.</p>
          <p class="font-weight-bold text-center">Modo de preparo:</p>
             <p class="h5 text-center">Bata os ingredientes no liquidificador com meio litro de água. Depois, acrescente mais, aproximadamente, 1,5 litros de água. Mexa bem e adoce a gosto.</p><br>
             
             
             <div class="text-center">     
                <img src="img/antioxidant.jpg"class="img-fluid ">
            </div>
            
         <h4 class="font-weight-bold text-center">3. Suco de couve com laranja lima</h4>
          <p class="font-weight-bold text-center">Ingredientes:</p> 
             <p class="h5 text-center">1 cenoura grande, 2 dedinhos de raiz de gengibre, 1 pepino, 2 folhas de couve manteiga e 1 laranja lima.</p>
          <p class="font-weight-bold text-center">Modo de preparo:</p>
             <p class="h5 text-center">Bata os ingredientes no liquidificador com meio litro de água. Depois, acrescente mais, aproximadamente, 1,5 litros de água. Mexa bem e adoce a gosto.</p><br> 
             
            
           <h4 class="font-weight-bold text-center">4. Suco detox de uva, kiwi e laranja lima</h4>
          <p class="font-weight-bold text-center">Ingredientes:</p> 
             <p class="h5 text-center">1 xícara de uva itália sem as sementes, 3 kiwis, 1 laranja lima descascada deixando a parte branca.</p>
          <p class="font-weight-bold text-center">Modo de preparo:</p>
             <p class="h5 text-center">Bata os ingredientes no liquidificador com meio litro de água. Depois, acrescente mais, aproximadamente, 1,5 litros de água. Mexa bem e adoce a gosto.</p><br> 
             
           <h4 class="font-weight-bold text-center">5. Suco de cenoura e beterraba</h4>
          <p class="font-weight-bold text-center">Ingredientes:</p> 
             <p class="h5 text-center">4 cenouras, 1 beterraba com as folhas verdes.</p>
          <p class="font-weight-bold text-center">Modo de preparo:</p>
             <p class="h5 text-center">Bata os ingredientes no liquidificador com meio litro de água. Depois, acrescente mais, aproximadamente, 1,5 litros de água. Mexa bem e adoce a gosto.</p><br>
             
             <div class="card text-center font-weight-bold">
              <div class="card-header">
               Fontes consultadas:
              </div>
              <div class="card-body">
                <blockquote class="blockquote mb-0">
                  <footer class="blockquote-footer"> Escrito por Bruna Stuppiello: Redação Minha Vida<cite title="Source Title">, Nutrólogo Roberto Navarro Nutricionista Rosana Farah, professora da Universidade Presbiteriana Mackenzie e membro da clínica Ávvia Medicina e Nutrição.</cite>
                     <a href="https://www.minhavida.com.br/alimentacao/tudo-sobre/32858-suco-detox" target="_blank">https://www.minhavida.com.br/alimentacao/tudo-sobre/32858-suco-detox</a></footer>
                </blockquote>
              </div>
            </div>
      </div>
     
      
       <div class="p-3 mb-2 bg-secondary text-white" id="page-footer">
           <footer class="page-footer font-small stylish-color-dark pt-4">

    <!-- Footer Links -->
    <div class="container text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-4 mx-auto">

          <!-- Content -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Mind & Health</h5>
          <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit amet, consectetur
            adipisicing elit.</p>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Informações</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Sobre</a>
            </li>
            <li>
              <a href="#!" class="text-white">Artigos</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ebooks</a>
            </li>
            <li>
              <a href="#!" class="text-white">Termos e condições de uso</a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-2 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Atendimento</h5>

          <ul class="list-unstyled">
            <li>
              <a href="#!" class="text-white">Dúvidas</a>
            </li>
            <li>
              <a href="#!" class="text-white">Ajuda</a>
            </li>
            <li>
              <a href="#!" class="text-white">mindhealth@hotmail.com</a>
            </li>
            <li>
              <a href="#!" class="text-white"></a>
            </li>
          </ul>

        </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none">

        <!-- Grid column -->
        <div class="col-md-3 mx-auto">

          <!-- Links -->
          <h5 class="font-weight-bold text-uppercase mt-3 mb-4 text-success">Newsletter</h5>
          <p>Assine nossa newsletter e receba dicas e novidades para uma vida mais saudável</p>
     <!-- Icone Newsletter-->     
    <div class="container">
      <div class="row">
            <div class="thumbnail center well well-sm text-center">
                    <form action="" method="post" role="form">
                        <div class="input-group">
                          <span class="input-group-addon">
                           <!--Aqui deverar ir um icone ou alguma estilização para o newsletter :) -->
                          </span>
                          <input class="form-control" type="text" id="" name="" placeholder="Seu melhor e-mail">
                        </div>
                        <input type="submit" value="Cadastrar" class="btn btn-large btn-primary bg-success"/>
                  </form>
                </div>    
            </div>
  </div>

        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
    <!-- Footer Links -->

    <hr>
            <div class="col-lg-6 col-md-12">
                    <h5 class="white-text text-success">Redes Sociais</h5>
                    <ul class="list-inline redes text-right">
                    <a href="https://www.facebook.com/Mind-Health-1017661845098135/?modal=admin_todo_tour" rel="stylesheet"><i class="fab fa-facebook fa-2x"></i></a>
                    <a href="htthttps://www.instagram.com/mind_healthms/?hl=pt-b" rel="stylesheet"><i class="fab fa-instagram fa-2x"></i></a>
                    <a href=""><i class="fab fa-youtube fa-2x"></i></a>
                    <a href="" rel="stylesheet"><i class="fab fa-twitter fa-2x"></i></a>
                </ul>
        </div>
    <hr>


    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2019 Copyright:
      <a href="https://github.com/KennedyAndrade/Trabalho-Projeto-3/" class="text-success"> Mind & Health</a>
    </div>
    <!-- Copyright -->
</footer>
</div>
<!-- Footer -->
      
      
      <!-- Bootstrap JS -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    <script type="text/javascript">
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            $(".navbar").removeClass("bigMenu");
        }else{
            $(".navbar").addClass("bigMenu");
        }
    });
</script>
  </body>
</html>